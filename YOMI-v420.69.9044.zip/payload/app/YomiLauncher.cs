using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

public static class YomiLauncher
{
    [STAThread]
    public static int Main(string[] args)
    {
        try
        {
            string mode = (args.Length > 0 ? args[0] : "controller").ToLowerInvariant();
            string appDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');

            if (mode == "controller" || mode == "player" || mode == "expedition" || mode == "settings")
            {
                string shell = Path.Combine(appDir, "YomiControllerWpf.exe");
                if (File.Exists(shell))
                {
                    var shellPsi = new ProcessStartInfo();
                    shellPsi.FileName = shell;
                    shellPsi.Arguments = mode == "settings" ? "--settings" : (mode == "expedition" ? "--expedition" : "");
                    shellPsi.WorkingDirectory = appDir;
                    shellPsi.UseShellExecute = false;
                    shellPsi.CreateNoWindow = false;
                    Process.Start(shellPsi);
                    return 0;
                }

                // Fail-safe only: old Controller remains a recoverability surface if the
                // canonical WPF shell is missing or damaged.
                mode = mode == "settings" ? "legacy-settings" : "legacy-controller";
            }

            bool updateMode = mode == "update" || mode == "update-auto";
            string scriptName = updateMode ? "update.ps1" :
                (mode == "legacy-settings" ? "settings.ps1" : "controller.ps1");
            string script = Path.Combine(appDir, scriptName);

            if (!File.Exists(script))
                return 2;

            if (mode == "settings")
            {
                try
                {
                    using (EventWaitHandle activate = EventWaitHandle.OpenExisting(@"Local\YOMI_SETTINGS_ACTIVATE_V4"))
                    {
                        activate.Set();
                        return 0;
                    }
                }
                catch (WaitHandleCannotBeOpenedException)
                {
                }
            }

            string powershell = Path.Combine(
                Environment.SystemDirectory,
                @"WindowsPowerShell\v1.0\powershell.exe"
            );

            var psi = new ProcessStartInfo();
            psi.FileName = powershell;
            psi.Arguments =
                "-NoProfile -ExecutionPolicy Bypass -STA -File \"" +
                script.Replace("\"", "\\\"") + "\"" +
                (mode == "update" ? " -Manual" : "");
            string launchWorkingDirectory = appDir;
            if (updateMode)
            {
                launchWorkingDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "YOMI", "updates"
                );
                Directory.CreateDirectory(launchWorkingDirectory);
            }
            psi.WorkingDirectory = launchWorkingDirectory;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.WindowStyle = ProcessWindowStyle.Normal;

            Process.Start(psi);
            return 0;
        }
        catch
        {
            return 1;
        }
    }
}
