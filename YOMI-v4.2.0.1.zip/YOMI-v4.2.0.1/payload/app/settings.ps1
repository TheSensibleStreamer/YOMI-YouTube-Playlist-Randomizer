$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'common.ps1')
Initialize-YomiData
$config = Get-YomiConfig
$yomiVersion = Get-YomiVersionText

$form = New-Object System.Windows.Forms.Form
$form.Text = "YOMI $yomiVersion - YouTube OBS Music Interface"
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(1010,850)
$form.MinimumSize = $form.Size
$form.MaximumSize = $form.Size
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)
$settingsIcon = Join-Path $InstallRoot 'assets\yomi-settings-v408.ico'
if (Test-Path $settingsIcon) { try { $form.Icon = New-Object System.Drawing.Icon($settingsIcon) } catch {} }

$title = New-Object System.Windows.Forms.Label
$title.Text = 'YOMI'
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold',24)
$title.Location = New-Object System.Drawing.Point(20,12)
$title.Size = New-Object System.Drawing.Size(100,42)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'YouTube OBS Music Interface  |  Playlist randomizer, player and modular stream overlay'
$subtitle.Location = New-Object System.Drawing.Point(125,26)
$subtitle.Size = New-Object System.Drawing.Size(780,26)
$subtitle.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($subtitle)

function Add-Label($parent,$text,$x,$y,$w=180,$h=24) {
    $c=New-Object System.Windows.Forms.Label; $c.Text=$text
    $c.Location=New-Object System.Drawing.Point($x,$y); $c.Size=New-Object System.Drawing.Size($w,$h)
    $parent.Controls.Add($c); return $c
}
function Add-Combo($parent,$x,$y,$w,$items,$selected) {
    $c=New-Object System.Windows.Forms.ComboBox; $c.Location=New-Object System.Drawing.Point($x,$y)
    $c.Size=New-Object System.Drawing.Size($w,28); $c.DropDownStyle='DropDownList'
    [void]$c.Items.AddRange($items); $c.SelectedItem=[string]$selected
    if($c.SelectedIndex -lt 0 -and $c.Items.Count -gt 0){$c.SelectedIndex=0}
    $parent.Controls.Add($c); return $c
}
function Add-Number($parent,$x,$y,$w,$min,$max,$value) {
    $n=New-Object System.Windows.Forms.NumericUpDown; $n.Location=New-Object System.Drawing.Point($x,$y)
    $n.Size=New-Object System.Drawing.Size($w,28); $n.Minimum=[decimal]$min; $n.Maximum=[decimal]$max
    $n.Value=[decimal][Math]::Max($min,[Math]::Min($max,[int]$value)); $parent.Controls.Add($n); return $n
}
function Add-Check($parent,$text,$x,$y,$checked,$w=200) {
    $c=New-Object System.Windows.Forms.CheckBox; $c.Text=$text; $c.Location=New-Object System.Drawing.Point($x,$y)
    $c.Size=New-Object System.Drawing.Size($w,26); $c.Checked=[bool]$checked; $parent.Controls.Add($c); return $c
}
function Add-Text($parent,$x,$y,$w,$text) {
    $c=New-Object System.Windows.Forms.TextBox; $c.Location=New-Object System.Drawing.Point($x,$y)
    $c.Size=New-Object System.Drawing.Size($w,28); $c.Text=[string]$text; $parent.Controls.Add($c); return $c
}
function Hex-Color([string]$hex) {
    try { return [System.Drawing.ColorTranslator]::FromHtml($hex) } catch { return [System.Drawing.Color]::White }
}
function Map-Color([string]$name) {
    switch ($name) {
        'YOMI Cream' { '#F2F0E8' } 'White' { '#FFFFFF' } 'Black' { '#000000' }
        'Near Black' { '#151515' } 'Dark Gray' { '#252525' } 'Gray' { '#8A8A84' }
        'Pink' { '#FF86C8' } 'Lavender' { '#C4A7FF' } 'Purple' { '#9B7BFF' }
        'Cyan' { '#70E1F5' } 'Blue' { '#72A7FF' } 'Green' { '#7BE495' }
        'Yellow' { '#FFD166' } 'Orange' { '#FFA552' } 'Red' { '#FF6B6B' }
        default { '#F2F0E8' }
    }
}
function Color-Name([string]$hex,[string]$fallback='YOMI Cream') {
    foreach($n in @('YOMI Cream','White','Black','Near Black','Dark Gray','Gray','Pink','Lavender','Purple','Cyan','Blue','Green','Yellow','Orange','Red')) {
        if((Map-Color $n) -ieq $hex){return $n}
    }
    return $fallback
}

$tabs=New-Object System.Windows.Forms.TabControl
$tabs.Location=New-Object System.Drawing.Point(20,62); $tabs.Size=New-Object System.Drawing.Size(955,650)
$form.Controls.Add($tabs)
function New-Tab($name){$t=New-Object System.Windows.Forms.TabPage;$t.Text=$name;[void]$tabs.TabPages.Add($t);return $t}

# GENERAL / PLAYER
$general=New-Tab 'General / Player'
Add-Label $general 'YouTube playlist link or playlist ID:' 18 22 320 | Out-Null
$playlist=New-Object System.Windows.Forms.TextBox; $playlist.Location=New-Object System.Drawing.Point(18,48); $playlist.Size=New-Object System.Drawing.Size(890,27); $playlist.Text=[string]$config.playlist; $general.Controls.Add($playlist)
Add-Label $general 'Page preset:' 18 100 95 | Out-Null
$generalPreset=Add-Combo $general 125 96 240 @('Default','Audio-only Player','Efficient Video Player','Quality Video Player','Streamer / OBS','Custom') ([string]$config.general_preset)
$generalPresetHint=Add-Label $general 'Playlist identity is never part of a preset. Changing mode or Player video marks this page Custom.' 385 99 520 42
$generalPresetHint.ForeColor=[System.Drawing.Color]::DimGray
Add-Label $general 'YOMI mode:' 18 150 100 | Out-Null
$mode=Add-Combo $general 125 146 240 @('Player','Streamer / OBS') ([string]$config.app_mode)
$modeHint=Add-Label $general 'Player = lightweight playlist randomizer/player. Streamer / OBS adds the one-source overlay and presentation cache.' 385 149 520 42
$modeHint.ForeColor=[System.Drawing.Color]::DimGray
Add-Label $general 'Player video:' 18 200 100 | Out-Null
$playerQuality=Add-Combo $general 125 196 240 @('Off (audio only)','144p','240p','360p','480p','720p','Best') ([string]$config.player_video_quality)
$playerHint=Add-Label $general 'Audio-only is the lowest-overhead default. Video quality applies only in Player mode and opens an mpv video window.' 385 199 520 44
$playerHint.ForeColor=[System.Drawing.Color]::DimGray
$generalNote=Add-Label $general 'Shuffle Playlist is the normal update action: it reloads the current YouTube playlist, preserves duplicate entries, randomizes the whole list, resets cache mapping and starts from the new track 1.' 18 265 885 58
$generalNote.ForeColor=[System.Drawing.Color]::DimGray
$applyNote=Add-Label $general 'Saving is silent. Browser styling/layout changes refresh automatically. Restart YOMI for player mode, media quality, cache pipeline and generated-visualizer changes.' 18 342 885 48
$applyNote.ForeColor=[System.Drawing.Color]::DarkGoldenrod
$restoreDefaults=New-Object System.Windows.Forms.Button; $restoreDefaults.Text='RESTORE DEFAULT SETTINGS...'; $restoreDefaults.Location=New-Object System.Drawing.Point(18,410); $restoreDefaults.Size=New-Object System.Drawing.Size(250,38); $general.Controls.Add($restoreDefaults)
$restoreHint=Add-Label $general 'Restores YOMI options and output layouts while preserving your playlist, playback history, installed components and Defender choice. Media affected by the restored quality/crop/visualizer settings is rebuilt as needed.' 290 407 615 64
$restoreHint.ForeColor=[System.Drawing.Color]::DimGray

# OBS OVERLAY
$obs=New-Tab 'OBS Overlay'
Add-Label $obs 'Canvas:' 18 24 70 | Out-Null
$canvasPreset=Add-Combo $obs 90 20 180 @('1280 x 720','1920 x 1080','2560 x 1440','3840 x 2160','Custom') ([string]$config.canvas_preset)
Add-Label $obs 'Width:' 290 24 55 | Out-Null
$canvasW=Add-Number $obs 345 20 90 320 7680 ([int]$config.canvas_width)
Add-Label $obs 'Height:' 455 24 60 | Out-Null
$canvasH=Add-Number $obs 515 20 90 240 4320 ([int]$config.canvas_height)
Add-Label $obs 'Corner:' 630 24 65 | Out-Null
$corner=Add-Combo $obs 695 20 190 @('Top Left','Top Right','Bottom Left','Bottom Right') ([string]$config.corner)

Add-Label $obs 'Media size:' 18 75 90 | Out-Null
$mediaPreset=Add-Combo $obs 110 71 160 @('Auto','Compact','Small','Medium','Large','Extra Large','Custom') ([string]$config.media_size_preset)
Add-Label $obs 'Width:' 290 75 55 | Out-Null
$mediaW=Add-Number $obs 345 71 90 40 800 ([int]$config.media_width)
Add-Label $obs 'Height:' 455 75 60 | Out-Null
$mediaH=Add-Number $obs 515 71 90 22 450 ([int]$config.media_height)
Add-Label $obs 'Video zoom:' 630 75 85 | Out-Null
$videoZoom=Add-Number $obs 720 71 80 100 200 ([int][Math]::Round(([double]$config.video_zoom)*100))
Add-Label $obs '%' 805 75 25 | Out-Null

$moduleBox=New-Object System.Windows.Forms.GroupBox; $moduleBox.Text='Overlay modules'; $moduleBox.Location=New-Object System.Drawing.Point(18,120); $moduleBox.Size=New-Object System.Drawing.Size(875,90); $obs.Controls.Add($moduleBox)
$art=Add-Check $moduleBox 'Artwork / thumbnail' 15 28 $config.artwork_enabled 175
$video=Add-Check $moduleBox 'Tiny video' 200 28 $config.video_enabled 120
$titleCheck=Add-Check $moduleBox 'Song title' 330 28 $config.title_enabled 115
$channel=Add-Check $moduleBox 'Channel name' 455 28 $config.channel_enabled 135
$viz=Add-Check $moduleBox 'Retro visualizer' 600 28 $config.visualizer_enabled 150
$smartCrop=Add-Check $moduleBox 'Smart crop black/letterbox borders' 15 57 $config.smart_artwork_crop 280

Add-Label $obs 'Overlay video quality:' 18 235 145 | Out-Null
$overlayVideoQuality=Add-Combo $obs 165 231 190 @('144p (fastest)','240p','360p','480p','720p','Best compatible') ([string]$config.overlay_video_quality)
Add-Label $obs 'Video FPS:' 375 235 95 | Out-Null
$videoFps=Add-Combo $obs 470 231 180 @('30 FPS','60 FPS when available') ([string]$config.video_fps)
Add-Label $obs 'Cache limit MB:' 670 235 110 | Out-Null
$videoCacheLimit=Add-Number $obs 785 231 90 64 8192 ([int]$config.video_cache_limit_mb)
$qualityWarning=Add-Label $obs 'Large-video mode: 720p and Best compatible can take longer to prepare and can use substantially more bandwidth, disk cache and OBS decoding. Long videos may be tens or hundreds of MB. YOMI still enforces the configured cache ceiling and compatibility fallbacks.' 18 278 870 64
$qualityWarning.ForeColor=[System.Drawing.Color]::DarkGoldenrod
$obsHint=Add-Label $obs '60 FPS video is preferred only when YouTube offers it at the selected resolution; YOMI does not fabricate motion by duplicating 30 FPS frames. Disabled classic modules avoid their work unless an enabled Director output needs it. The visualizer begins at the final media pixel; text keeps separate padding.' 18 360 870 72
$obsHint.ForeColor=[System.Drawing.Color]::DimGray
Add-Label $obs 'Page preset:' 18 458 95 | Out-Null
$overlayPreset=Add-Combo $obs 120 454 210 @('Default','Gaming Light','Artwork Radio','Full Strip','Video Showcase','Custom') ([string]$config.overlay_preset)
$overlayPresetHint=Add-Label $obs 'Applies the complete classic-overlay page. Touching any canvas, media, module, crop, quality, FPS, zoom or cache option marks it Custom.' 350 457 540 52
$overlayPresetHint.ForeColor=[System.Drawing.Color]::DimGray

# STYLE
$style=New-Tab 'Text & Style'
Add-Label $style 'Style preset:' 18 24 95 | Out-Null
$stylePreset=Add-Combo $style 120 20 190 @('Default','Classic','Minimal','Retro','Neon','Pastel','Arcade','Custom') ([string]$config.style_preset)
Add-Label $style 'Font:' 335 24 55 | Out-Null
$font=Add-Combo $style 390 20 230 @('Bahnschrift Condensed','Segoe UI','Arial','Arial Black','Georgia','Times New Roman','Trebuchet MS','Verdana','Tahoma','Segoe Print','Segoe Script','Comic Sans MS','Impact','Courier New') ([string]$config.text_font)

Add-Label $style 'Text color:' 18 75 90 | Out-Null
$textColor=Add-Combo $style 120 71 160 @('YOMI Cream','White','Black','Pink','Lavender','Purple','Cyan','Blue','Green','Yellow','Orange','Red') (Color-Name ([string]$config.text_color) 'YOMI Cream')
Add-Label $style 'Outline color:' 310 75 100 | Out-Null
$outlineColor=Add-Combo $style 415 71 160 @('Near Black','Black','Dark Gray','White','Pink','Purple','Blue','Red') (Color-Name ([string]$config.outline_color) 'Near Black')
Add-Label $style 'Outline px:' 610 75 80 | Out-Null
$outlinePx=Add-Number $style 690 71 70 0 12 ([int]$config.text_outline)
Add-Label $style 'Opacity %:' 775 75 80 | Out-Null
$textOpacity=Add-Number $style 855 71 65 20 100 ([int][Math]::Round(([double]$config.text_opacity)*100))

Add-Label $style 'Text size:' 18 125 80 | Out-Null
$textSize=Add-Number $style 120 121 80 10 120 ([int]$config.text_size)
Add-Label $style 'Alignment:' 230 125 80 | Out-Null
$textAlign=Add-Combo $style 310 121 140 @('Auto','Left','Center','Right') ([string]$config.text_alignment)
Add-Label $style 'Title/channel spacing:' 475 125 145 | Out-Null
$textSpacing=Add-Combo $style 625 121 135 @('Tight','Normal','Loose') ([string]$config.title_channel_spacing)
$glow=Add-Check $style 'Subtle text glow' 785 121 $config.text_glow 140

$mediaStyleBox=New-Object System.Windows.Forms.GroupBox; $mediaStyleBox.Text='Media frame'; $mediaStyleBox.Location=New-Object System.Drawing.Point(18,175); $mediaStyleBox.Size=New-Object System.Drawing.Size(875,95); $style.Controls.Add($mediaStyleBox)
$borderOn=Add-Check $mediaStyleBox 'Border' 15 29 $config.media_border_enabled 90
Add-Label $mediaStyleBox 'Width px:' 115 31 70 | Out-Null
$borderPx=Add-Number $mediaStyleBox 185 27 65 0 8 ([int]$config.media_border_px)
Add-Label $mediaStyleBox 'Color:' 275 31 55 | Out-Null
$borderColor=Add-Combo $mediaStyleBox 335 27 150 @('Dark Gray','Near Black','Black','White','Pink','Purple','Cyan','Blue') (Color-Name ([string]$config.media_border_color) 'Dark Gray')
Add-Label $mediaStyleBox 'Corners:' 515 31 70 | Out-Null
$cornerStyle=Add-Combo $mediaStyleBox 590 27 160 @('Square','Soft Rounded','Rounded') ([string]$config.media_corner_style)

$styleHint=Add-Label $style 'The list is intentionally curated instead of dumping hundreds of Windows fonts on you. Preview changes live before saving.' 18 290 870 36
$styleHint.ForeColor=[System.Drawing.Color]::DimGray

# VISUALIZER
$visual=New-Tab 'Visualizer'
Add-Label $visual 'Page preset:' 18 24 90 | Out-Null
$vizPreset=Add-Combo $visual 115 20 240 @('Default','Monolith Efficiency','Low Overhead Blocks','Broadcast','Smooth 60 FPS','Signal Analyzer','Neon Motion','Custom') ([string]$config.visualizer_preset)

Add-Label $visual 'Activity:' 18 76 70 | Out-Null
$activity=Add-Combo $visual 95 72 145 @('Subtle','Normal','Active','Punchy') ([string]$config.visualizer_activity)
Add-Label $visual 'Opacity %:' 265 76 85 | Out-Null
$opacityPct=Add-Number $visual 350 72 90 5 80 ([int][Math]::Round(([double]$config.visualizer_opacity)*100))
Add-Label $visual 'Pixels:' 470 76 60 | Out-Null
$chunkName=$(if([int]$config.visualizer_internal_width -le 12){'Monolith (12x4)'}elseif([int]$config.visualizer_internal_width -le 16){'Mega Blocks (16x5)'}elseif([int]$config.visualizer_internal_width -le 20){'Giant Blocks (20x6)'}elseif([int]$config.visualizer_internal_width -le 28){'Huge Blocks (28x8)'}elseif([int]$config.visualizer_internal_width -le 40){'Extra Chunky (40x10)'}elseif([int]$config.visualizer_internal_width -le 48){'Chunky (48x12)'}elseif([int]$config.visualizer_internal_width -le 64){'Fine (64x18)'}elseif([int]$config.visualizer_internal_width -le 96){'Extra Fine (96x24)'}elseif([int]$config.visualizer_internal_width -le 128){'Ultra Fine (128x32)'}elseif([int]$config.visualizer_internal_width -le 160){'Microscopic (160x40)'}else{'Maximum Detail (192x48)'})
$chunk=Add-Combo $visual 530 72 190 @('Monolith (12x4)','Mega Blocks (16x5)','Giant Blocks (20x6)','Huge Blocks (28x8)','Extra Chunky (40x10)','Chunky (48x12)','Fine (64x18)','Extra Fine (96x24)','Ultra Fine (128x32)','Microscopic (160x40)','Maximum Detail (192x48)') $chunkName
Add-Label $visual 'Length:' 720 76 65 | Out-Null
$vizLength=Add-Combo $visual 785 72 135 @('Short','Medium','Wide','Extra Wide') $(if([double]$config.visualizer_length_multiplier -le 2.25){'Short'}elseif([double]$config.visualizer_length_multiplier -le 3.25){'Medium'}elseif([double]$config.visualizer_length_multiplier -ge 5.25){'Extra Wide'}else{'Wide'})

Add-Label $visual 'Color mode:' 18 130 90 | Out-Null
$vizColorMode=Add-Combo $visual 115 126 145 @('Solid','Rainbow','Gradient') ([string]$config.visualizer_color_mode)
Add-Label $visual 'Solid color:' 285 130 85 | Out-Null
$vizSolid=Add-Combo $visual 375 126 145 @('Gray','YOMI Cream','White','Pink','Lavender','Purple','Cyan','Blue','Green','Yellow','Orange','Red') (Color-Name ([string]$config.visualizer_solid_color) 'Gray')
Add-Label $visual 'Gradient:' 545 130 75 | Out-Null
$vizGradient=Add-Combo $visual 620 126 145 @('Sunset','Ocean','Pastel','Fire','Forest','Mono') ([string]$config.visualizer_gradient_preset)
Add-Label $visual 'Direction:' 785 130 70 | Out-Null
$gradientOrientation=Add-Combo $visual 855 126 75 @('Horizontal','Vertical') ([string]$config.visualizer_gradient_orientation)

Add-Label $visual 'Bars:' 18 184 60 | Out-Null
$vizDirection=Add-Combo $visual 115 180 145 @('Normal','Mirrored') ([string]$config.visualizer_direction)
Add-Label $visual 'Layer:' 285 184 55 | Out-Null
$vizLayer=Add-Combo $visual 375 180 145 @('Behind text','Above text') ([string]$config.visualizer_layer)
Add-Label $visual 'Shape:' 545 184 65 | Out-Null
$vizShape=Add-Combo $visual 610 180 155 @('Spectrum','Center Mirror','Oscilloscope','Dots','Skyline','Particle Field','Twin Rails') ([string]$config.visualizer_shape)
Add-Label $visual 'Anchor:' 785 184 65 | Out-Null
$vizAnchor=Add-Combo $visual 850 180 80 @('Source','Bottom','Center','Top') ([string]$config.visualizer_vertical_anchor)

Add-Label $visual 'Bar spacing:' 18 238 90 | Out-Null
$vizSpacing=Add-Combo $visual 115 234 145 @('None','Light','Wide') ([string]$config.visualizer_bar_spacing)
Add-Label $visual 'Peak glow:' 285 238 85 | Out-Null
$vizPeakGlow=Add-Combo $visual 375 234 145 @('Off','Subtle','Strong') ([string]$config.visualizer_peak_glow)
Add-Label $visual 'Frequency scale:' 545 238 115 | Out-Null
$vizFrequency=Add-Combo $visual 665 234 160 @('Logarithmic','Linear') ([string]$config.visualizer_frequency_scale)
Add-Label $visual 'Visualizer FPS:' 18 292 105 | Out-Null
$vizFps=Add-Combo $visual 125 288 145 @('30 FPS','60 FPS') ([string]$config.visualizer_fps)
Add-Label $visual 'High-frequency trim %:' 305 292 165 | Out-Null
$vizHighTrim=Add-Number $visual 475 288 80 0 60 ([int]$config.visualizer_high_frequency_trim)
$visualHint=Add-Label $visual 'Monolith/Mega/Giant Blocks deliberately stretch very few generated pixels and minimize visualizer preparation/cache cost. Microscopic/Maximum Detail push in the opposite direction. High-frequency trim remaps useful bins across the full width. Generation-affecting changes rebuild cached visualizers.' 18 344 875 70
$visualHint.ForeColor=[System.Drawing.Color]::DimGray
$visualCost=Add-Label $visual '' 18 418 875 48
$visualCost.BorderStyle='FixedSingle';$visualCost.ForeColor=[System.Drawing.Color]::DimGray

# PERFORMANCE
$perf=New-Tab 'Performance'
Add-Label $perf 'Page preset:' 18 24 90 | Out-Null
$performancePreset=Add-Combo $perf 115 20 220 @('Default','Gaming','Rapid Cache','Deep Cache','Custom') ([string]$config.performance_preset)
Add-Label $perf 'Background preparation:' 18 76 165 | Out-Null
$perfItems=@('Gaming / Lowest overhead (1 worker)','Balanced (2 workers)','Fast caching (4 workers)','Maximum caching (8 workers)')
$perfSel=$perfItems[0]; if([int]$config.cache_workers -eq 2){$perfSel=$perfItems[1]}elseif([int]$config.cache_workers -ge 8){$perfSel=$perfItems[3]}elseif([int]$config.cache_workers -ge 4){$perfSel=$perfItems[2]}
$performance=Add-Combo $perf 190 72 320 $perfItems $perfSel
Add-Label $perf 'Browser Source FPS:' 535 76 145 | Out-Null
$browserFps=Add-Combo $perf 680 72 130 @('Auto','15 FPS','30 FPS','60 FPS') ([string]$config.browser_fps_mode)
$perfHint=Add-Label $perf 'Default is Balanced / 2 workers with four complete tracks ahead. Maximum / 8 workers can fill a deep cache much faster, but it can hammer CPU, network, disk and Defender at the same time; use it only when the streaming machine has measured headroom.' 18 114 880 52
$perfHint.ForeColor=[System.Drawing.Color]::DimGray
$loudness=Add-Check $perf 'Track loudness leveling (requires FFmpeg Media Tools)' 18 177 $config.loudness_normalization 390
Add-Label $perf 'Complete tracks ready ahead:' 435 181 200 | Out-Null
$prefetch=Add-Number $perf 640 177 80 1 20 ([int]$config.prefetch_ahead)
Add-Label $perf 'Video selection:' 18 232 120 | Out-Null
$videoPreference=Add-Combo $perf 145 228 230 @('Prefer selected maximum','Prefer lowest compatible') ([string]$config.video_preference)
Add-Label $perf 'Audio quality target:' 400 232 145 | Out-Null
$audioQuality=Add-Combo $perf 550 228 215 @('Low (~64 kbps)','Standard (~128 kbps)','High (~160 kbps)','Best available') ([string]$config.audio_quality)

Add-Label $perf 'Audio selection:' 18 280 120 | Out-Null
$audioPreference=Add-Combo $perf 145 276 230 @('Prefer selected maximum','Prefer lowest compatible') ([string]$config.audio_preference)
$audioHint=Add-Label $perf 'Maximum preference chooses the best compatible stream near the selected target. Lowest preference minimizes transfer/cache size and can sound or look noticeably rougher.' 400 274 480 48
$audioHint.ForeColor=[System.Drawing.Color]::DarkGoldenrod
$perfNote=Add-Label $perf 'One ready-ahead number means the whole damn track: audio, metadata, gain and every enabled Streamer/Director media requirement. At 720p/Best, the video-cache ceiling can prevent all 20 from fitting. Player mode caches audio bundles only. Any individual change marks this page Custom.' 18 342 880 72
$perfNote.ForeColor=[System.Drawing.Color]::DimGray
$defenderManaged=Test-Path (Join-Path $DataRoot 'defender-yt-dlp-process-exclusion.txt')
$defenderText=$(if($defenderManaged){'Windows Defender performance option: ENABLED for YOMI yt-dlp.exe only. Uninstall removes the YOMI-managed exclusion.'}else{'Windows Defender performance option: OFF. The first installer screen has the explicit unchecked opt-in below the profile choices.'})
$defenderStatus=Add-Label $perf $defenderText 18 430 880 48
$defenderStatus.ForeColor=$(if($defenderManaged){[System.Drawing.Color]::DarkGreen}else{[System.Drawing.Color]::DarkGoldenrod})

# DIRECTOR MODE
$director=New-Tab 'Director Mode'
$directorOn=Add-Check $director 'Enable Director Mode / modular broadcast engine' 18 18 $config.director_mode 390
Add-Label $director 'Page preset:' 455 22 95 | Out-Null
$directorPreset=Add-Combo $director 555 18 250 @('Default','Pirate Radio','Culture Desk','Control Room','Full Science','Custom') ([string]$config.director_preset)
Add-Label $director 'World / theme:' 18 64 115 | Out-Null
$directorThemes=@('Classic','Pirate Radio','Control Room','Cyberpunk Lab','Record Store','Archive Terminal','Public Access','Museum Label','Arcade','Brutalist Industrial','Spacecraft','Jazz Club')
$directorTheme=Add-Combo $director 140 60 200 $directorThemes ([string]$config.director_theme)
Add-Label $director 'Timeline:' 370 64 75 | Out-Null
$directorTimeline=Add-Combo $director 450 60 180 @('Off','Broadcast Rotation','Rapid Rotation','Cinematic') ([string]$config.director_timeline)
Add-Label $director 'Motion:' 660 64 70 | Out-Null
$directorMotion=Add-Combo $director 730 60 150 @('Off','Subtle','Full') ([string]$config.director_motion)

Add-Label $director 'Palette:' 18 110 105 | Out-Null
$directorPalette=Add-Combo $director 140 106 200 @('Track identity','Theme fixed') ([string]$config.director_palette)
Add-Label $director 'Stats detail:' 370 110 95 | Out-Null
$statsDetail=Add-Combo $director 470 106 160 @('Broadcast','Stats for Nerds','Completely Unhinged') ([string]$config.stats_detail)
Add-Label $director 'Viz shape:' 660 110 80 | Out-Null
$directorVizShape=Add-Combo $director 740 106 165 @('Use global','Spectrum','Center Mirror','Oscilloscope','Dots','Skyline','Particle Field','Twin Rails') ([string]$config.director_visualizer_shape)

$commentOn=Add-Check $director 'Featured Comment (low-priority, relevance-sorted)' 18 158 $config.featured_comment_enabled 390
Add-Label $director 'Maximum characters:' 420 162 155 | Out-Null
$commentChars=Add-Number $director 580 158 80 40 500 ([int]$config.comment_max_chars)
Add-Label $director 'Filter:' 680 162 50 | Out-Null
$commentFilter=Add-Combo $director 735 158 150 @('Basic safety','Strict','Off') ([string]$config.comment_filter_mode)
$commentHint=Add-Label $director 'One top-level comment runs outside essential bundle-worker slots. It is cached, plain-text only, URL-cleaned and hideable from Controller. The local word filter is a useful guard, not infallible moderation. “Featured” means YouTube relevance sorting.' 38 192 840 52
$commentHint.ForeColor=[System.Drawing.Color]::DimGray

$telemetryOn=Add-Check $director 'Broadcast telemetry and ridiculous derived statistics' 18 258 $config.telemetry_enabled 390
$probeOn=Add-Check $director 'Exact FFprobe codec/container/bitrate inspection' 420 258 $config.telemetry_probe_enabled 390
$historyOn=Add-Check $director 'Show persistent broadcast History module' 18 304 $config.history_enabled 330
Add-Label $director 'Keep entries:' 365 308 100 | Out-Null
$historyMax=Add-Number $director 465 304 80 10 1000 ([int]$config.history_max_entries)

$directorHint=Add-Label $director 'Director Mode adds modular Browser Sources, output groups, synchronized scene timelines, theme worlds, rules, history, Up Next, engineering telemetry, mission codes and culture widgets. Disabled systems consume no download/probe work. The original /overlay remains the unchanged default.' 18 360 865 70
$directorHint.ForeColor=[System.Drawing.Color]::DimGray
$copySources=New-Object System.Windows.Forms.Button; $copySources.Text='COPY ALL SOURCE URLS'; $copySources.Location=New-Object System.Drawing.Point(18,455); $copySources.Size=New-Object System.Drawing.Size(220,38); $director.Controls.Add($copySources)
$openObsGuide=New-Object System.Windows.Forms.Button; $openObsGuide.Text='OPEN DIRECTOR OBS GUIDE'; $openObsGuide.Location=New-Object System.Drawing.Point(250,455); $openObsGuide.Size=New-Object System.Drawing.Size(235,38); $director.Controls.Add($openObsGuide)
$directorUrlHint=Add-Label $director 'Fixed URLs include /source/artwork, /video, /title, /channel, /visualizer, /stats, /technical, /comment, /history, /upnext and /mission. Configured groups use /source/1 through /source/6.' 18 515 865 52
$directorUrlHint.ForeColor=[System.Drawing.Color]::DimGray

# MODULAR OUTPUT GROUPS
$outputsTab=New-Tab 'Outputs 1-6'
Add-Label $outputsTab 'Page preset:' 16 13 95 | Out-Null
$outputsPreset=Add-Combo $outputsTab 115 9 240 @('Default','Minimal','Split Essentials','Broadcast Desk','Full Studio','Custom') ([string]$config.outputs_preset)
$outputsPresetHint=Add-Label $outputsTab 'A preset fills all six rows. Touching any row marks the page Custom.' 380 12 510 28
$outputsPresetHint.ForeColor=[System.Drawing.Color]::DimGray
Add-Label $outputsTab 'On' 16 55 32 | Out-Null
Add-Label $outputsTab 'ID' 48 55 28 | Out-Null
Add-Label $outputsTab 'Name' 80 55 115 | Out-Null
Add-Label $outputsTab 'Modules (comma separated, in display order)' 210 55 290 | Out-Null
Add-Label $outputsTab 'Layout' 510 55 100 | Out-Null
Add-Label $outputsTab 'Theme' 625 55 125 | Out-Null
Add-Label $outputsTab 'W' 770 55 55 | Out-Null
Add-Label $outputsTab 'H' 840 55 55 | Out-Null
$outputControls=@()
for($oid=1;$oid -le 6;$oid++) {
    $saved=@($config.director_outputs | Where-Object { [int]$_.id -eq $oid }) | Select-Object -First 1
    if($null -eq $saved) {
        $saved=[PSCustomObject]@{id=$oid;enabled=$false;name=("Output "+$oid);modules='title,channel';layout='Horizontal';theme='Global';width=900;height=180}
    }
    $y=85+(($oid-1)*66)
    $on=Add-Check $outputsTab '' 16 $y ([bool]$saved.enabled) 28
    Add-Label $outputsTab ([string]$oid) 50 ($y+3) 25 | Out-Null
    $name=Add-Text $outputsTab 80 $y 120 ([string]$saved.name)
    $mods=Add-Text $outputsTab 210 $y 290 ([string]$saved.modules)
    $layoutChoice=Add-Combo $outputsTab 510 $y 105 @('Broadcast Strip','Horizontal','Stack','Cards','Terminal','Timeline','Single') ([string]$saved.layout)
    $themeChoice=Add-Combo $outputsTab 625 $y 130 (@('Global')+$directorThemes) ([string]$saved.theme)
    $ow=Add-Number $outputsTab 770 $y 60 64 7680 ([int]$saved.width)
    $oh=Add-Number $outputsTab 840 $y 60 32 4320 ([int]$saved.height)
    $outputControls += [PSCustomObject]@{Id=$oid;Enabled=$on;Name=$name;Modules=$mods;Layout=$layoutChoice;Theme=$themeChoice;Width=$ow;Height=$oh}
}
$outputsHint=Add-Label $outputsTab 'Available modules: artwork, video, title, channel, visualizer, progress, stats, technical, pipeline, comment, history, upnext, mission. Put one module in a source or shovel several together. Multiple video sources share the download but each makes OBS perform another decode.' 18 500 870 70
$outputsHint.ForeColor=[System.Drawing.Color]::DimGray

# COMPONENTS
$componentsTab=New-Tab 'Components'
$compStatus=New-Object System.Windows.Forms.Label; $compStatus.Location=New-Object System.Drawing.Point(18,20); $compStatus.Size=New-Object System.Drawing.Size(860,190); $compStatus.BorderStyle='FixedSingle'; $componentsTab.Controls.Add($compStatus)
$denoBtn=New-Object System.Windows.Forms.Button; $denoBtn.Location=New-Object System.Drawing.Point(18,230); $denoBtn.Size=New-Object System.Drawing.Size(210,36); $componentsTab.Controls.Add($denoBtn)
$ffmpegBtn=New-Object System.Windows.Forms.Button; $ffmpegBtn.Location=New-Object System.Drawing.Point(240,230); $ffmpegBtn.Size=New-Object System.Drawing.Size(230,36); $componentsTab.Controls.Add($ffmpegBtn)
$refreshComponents=New-Object System.Windows.Forms.Button; $refreshComponents.Text='REFRESH STATUS'; $refreshComponents.Location=New-Object System.Drawing.Point(482,230); $refreshComponents.Size=New-Object System.Drawing.Size(150,36); $componentsTab.Controls.Add($refreshComponents)
$checkUpdates=New-Object System.Windows.Forms.Button; $checkUpdates.Text='CHECK FOR UPDATES'; $checkUpdates.Location=New-Object System.Drawing.Point(644,230); $checkUpdates.Size=New-Object System.Drawing.Size(190,36); $componentsTab.Controls.Add($checkUpdates)
$openData=New-Object System.Windows.Forms.Button; $openData.Text='OPEN DATA FOLDER'; $openData.Location=New-Object System.Drawing.Point(18,285); $openData.Size=New-Object System.Drawing.Size(180,36); $componentsTab.Controls.Add($openData)
$openProgram=New-Object System.Windows.Forms.Button; $openProgram.Text='OPEN PROGRAM FOLDER'; $openProgram.Location=New-Object System.Drawing.Point(210,285); $openProgram.Size=New-Object System.Drawing.Size(210,36); $componentsTab.Controls.Add($openProgram)
$uninstallBtn=New-Object System.Windows.Forms.Button; $uninstallBtn.Text='UNINSTALL YOMI...'; $uninstallBtn.Location=New-Object System.Drawing.Point(432,285); $uninstallBtn.Size=New-Object System.Drawing.Size(175,36); $componentsTab.Controls.Add($uninstallBtn)
$compHint=Add-Label $componentsTab 'Core: mpv + yt-dlp. Deno improves modern YouTube JavaScript challenge compatibility. FFmpeg Media Tools unlock loudness leveling, smart artwork crop and the retro visualizer. Removing an optional component does not delete your playlist/config/cache.' 18 345 865 78
$compHint.ForeColor=[System.Drawing.Color]::DimGray

# PREVIEW
$previewTab=New-Tab 'Live Preview'
$preview=New-Object System.Windows.Forms.Panel; $preview.Location=New-Object System.Drawing.Point(18,18); $preview.Size=New-Object System.Drawing.Size(890,420); $preview.BackColor=[System.Drawing.Color]::Black; $preview.BorderStyle='FixedSingle'; $previewTab.Controls.Add($preview)
$previewInfo=Add-Label $previewTab '' 18 455 885 100
$previewInfo.BorderStyle='FixedSingle'

# bottom buttons
$save=New-Object System.Windows.Forms.Button; $save.Text='SAVE SETTINGS'; $save.Location=New-Object System.Drawing.Point(20,730); $save.Size=New-Object System.Drawing.Size(145,40); $form.Controls.Add($save)
$shuffleBtn=New-Object System.Windows.Forms.Button; $shuffleBtn.Text='SHUFFLE PLAYLIST'; $shuffleBtn.Location=New-Object System.Drawing.Point(175,730); $shuffleBtn.Size=New-Object System.Drawing.Size(170,40); $form.Controls.Add($shuffleBtn)
$controllerBtn=New-Object System.Windows.Forms.Button; $controllerBtn.Text='OPEN CONTROLLER'; $controllerBtn.Location=New-Object System.Drawing.Point(355,730); $controllerBtn.Size=New-Object System.Drawing.Size(155,40); $form.Controls.Add($controllerBtn)
$copyOverlay=New-Object System.Windows.Forms.Button; $copyOverlay.Text='COPY OVERLAY URL'; $copyOverlay.Location=New-Object System.Drawing.Point(520,730); $copyOverlay.Size=New-Object System.Drawing.Size(165,40); $form.Controls.Add($copyOverlay)
$obsSetup=New-Object System.Windows.Forms.Button; $obsSetup.Text='OBS SETUP'; $obsSetup.Location=New-Object System.Drawing.Point(695,730); $obsSetup.Size=New-Object System.Drawing.Size(120,40); $form.Controls.Add($obsSetup)
$readme=New-Object System.Windows.Forms.Button; $readme.Text='README'; $readme.Location=New-Object System.Drawing.Point(825,730); $readme.Size=New-Object System.Drawing.Size(120,40); $form.Controls.Add($readme)
$credit=Add-Label $form 'Created and designed by TheSensibleStreamer  |  Powered by mpv | yt-dlp | FFmpeg  |  Development assistance by ChatGPT' 20 782 955 28
$credit.TextAlign='MiddleCenter'; $credit.ForeColor=[System.Drawing.Color]::DimGray
$saveResetTimer=New-Object System.Windows.Forms.Timer; $saveResetTimer.Interval=1700
$saveResetTimer.Add_Tick({$saveResetTimer.Stop();$save.Text='SAVE SETTINGS'})

$script:ApplyingGeneralPreset=$false
$script:ApplyingOverlayPreset=$false
$script:ApplyingCanvasPreset=$false
$script:ApplyingMediaPreset=$false
$script:ApplyingStylePreset=$false
$script:ApplyingVisualizerPreset=$false
$script:ApplyingPerformancePreset=$false
$script:ApplyingDirectorPreset=$false
$script:ApplyingOutputsPreset=$false

function Apply-GeneralPreset {
    if($script:ApplyingGeneralPreset){return}
    $script:ApplyingGeneralPreset=$true
    try{
        switch([string]$generalPreset.SelectedItem){
            'Default'{$mode.SelectedItem='Streamer / OBS';$playerQuality.SelectedItem='Off (audio only)'}
            'Audio-only Player'{$mode.SelectedItem='Player';$playerQuality.SelectedItem='Off (audio only)'}
            'Efficient Video Player'{$mode.SelectedItem='Player';$playerQuality.SelectedItem='240p'}
            'Quality Video Player'{$mode.SelectedItem='Player';$playerQuality.SelectedItem='720p'}
            'Streamer / OBS'{$mode.SelectedItem='Streamer / OBS';$playerQuality.SelectedItem='Off (audio only)'}
        }
    }finally{$script:ApplyingGeneralPreset=$false}
    Update-Dependencies;Update-Preview
}

function Apply-CanvasPreset {
    if($script:ApplyingCanvasPreset){return}
    $script:ApplyingCanvasPreset=$true
    try{
        switch([string]$canvasPreset.SelectedItem){
            '1280 x 720'{$canvasW.Value=1280;$canvasH.Value=720}
            '1920 x 1080'{$canvasW.Value=1920;$canvasH.Value=1080}
            '2560 x 1440'{$canvasW.Value=2560;$canvasH.Value=1440}
            '3840 x 2160'{$canvasW.Value=3840;$canvasH.Value=2160}
        }
    }finally{$script:ApplyingCanvasPreset=$false}
}
function Set-Media($w,$h,$t){$mediaW.Value=$w;$mediaH.Value=$h;$textSize.Value=$t}
function Apply-MediaPreset {
    if($script:ApplyingMediaPreset){return}
    $script:ApplyingMediaPreset=$true
    try{
        switch([string]$mediaPreset.SelectedItem){
            'Auto'{$w=[int][Math]::Round([int]$canvasW.Value*0.0625);$h=[int][Math]::Round($w*9/16);$t=[int][Math]::Round($w*33/160);Set-Media ([Math]::Max(40,$w)) ([Math]::Max(22,$h)) ([Math]::Max(12,[Math]::Min(72,$t)))}
            'Compact'{Set-Media 80 45 18}'Small'{Set-Media 120 68 26}'Medium'{Set-Media 160 90 33}'Large'{Set-Media 240 135 45}'Extra Large'{Set-Media 320 180 56}
        }
    }finally{$script:ApplyingMediaPreset=$false}
}

function Apply-OverlayPreset {
    if($script:ApplyingOverlayPreset){return}
    if([string]$overlayPreset.SelectedItem -eq 'Custom'){return}
    $script:ApplyingOverlayPreset=$true
    try{
        # Every curated classic-overlay bundle keeps the proven 160x90 joined
        # media geometry. The presets vary workload and presentation instead of
        # quietly moving a user's source around the canvas.
        $canvasPreset.SelectedItem='2560 x 1440';$corner.SelectedItem='Top Left'
        $mediaPreset.SelectedItem='Medium';$videoZoom.Value=125
        $smartCrop.Checked=$true;$titleCheck.Checked=$true;$channel.Checked=$true
        $overlayVideoQuality.SelectedItem='144p (fastest)';$videoFps.SelectedItem='30 FPS';$videoCacheLimit.Value=512
        switch([string]$overlayPreset.SelectedItem){
            'Default'{$art.Checked=$true;$video.Checked=$true;$viz.Checked=$true}
            'Gaming Light'{$art.Checked=$false;$video.Checked=$false;$viz.Checked=$false;$videoCacheLimit.Value=256}
            'Artwork Radio'{$art.Checked=$true;$video.Checked=$false;$viz.Checked=$true;$videoCacheLimit.Value=256}
            'Full Strip'{$art.Checked=$true;$video.Checked=$true;$viz.Checked=$true}
            'Video Showcase'{$art.Checked=$true;$video.Checked=$true;$viz.Checked=$true;$overlayVideoQuality.SelectedItem='360p';$videoFps.SelectedItem='60 FPS when available';$videoCacheLimit.Value=1024}
        }
    }finally{$script:ApplyingOverlayPreset=$false}
    Update-Dependencies;Update-QualityWarning;Update-Preview
}

function Apply-StylePreset {
    if($script:ApplyingStylePreset){return}
    $script:ApplyingStylePreset=$true
    try{
        switch([string]$stylePreset.SelectedItem){
            'Default'{$font.SelectedItem='Bahnschrift Condensed';$textColor.SelectedItem='YOMI Cream';$outlineColor.SelectedItem='Near Black';$outlinePx.Value=6;$textOpacity.Value=100;$textSize.Value=33;$textAlign.SelectedItem='Auto';$textSpacing.SelectedItem='Normal';$glow.Checked=$false;$borderOn.Checked=$true;$borderPx.Value=2;$borderColor.SelectedItem='Dark Gray';$cornerStyle.SelectedItem='Square'}
            'Classic'{$font.SelectedItem='Bahnschrift Condensed';$textColor.SelectedItem='YOMI Cream';$outlineColor.SelectedItem='Near Black';$outlinePx.Value=6;$glow.Checked=$false;$borderOn.Checked=$true;$borderColor.SelectedItem='Dark Gray';$cornerStyle.SelectedItem='Square'}
            'Minimal'{$font.SelectedItem='Segoe UI';$textColor.SelectedItem='White';$outlineColor.SelectedItem='Black';$outlinePx.Value=2;$glow.Checked=$false;$borderOn.Checked=$false;$cornerStyle.SelectedItem='Square'}
            'Retro'{$font.SelectedItem='Courier New';$textColor.SelectedItem='YOMI Cream';$outlineColor.SelectedItem='Black';$outlinePx.Value=4;$glow.Checked=$false;$borderOn.Checked=$true;$cornerStyle.SelectedItem='Square'}
            'Neon'{$font.SelectedItem='Arial Black';$textColor.SelectedItem='Cyan';$outlineColor.SelectedItem='Purple';$outlinePx.Value=4;$glow.Checked=$true;$borderOn.Checked=$true;$borderColor.SelectedItem='Purple';$cornerStyle.SelectedItem='Soft Rounded'}
            'Pastel'{$font.SelectedItem='Segoe Print';$textColor.SelectedItem='Pink';$outlineColor.SelectedItem='Purple';$outlinePx.Value=3;$glow.Checked=$true;$borderOn.Checked=$true;$borderColor.SelectedItem='Lavender';$cornerStyle.SelectedItem='Rounded'}
            'Arcade'{$font.SelectedItem='Impact';$textColor.SelectedItem='Yellow';$outlineColor.SelectedItem='Black';$outlinePx.Value=5;$glow.Checked=$true;$borderOn.Checked=$true;$borderColor.SelectedItem='Black';$cornerStyle.SelectedItem='Square'}
        }
    }finally{$script:ApplyingStylePreset=$false}
    Update-Preview
}

function Get-VisualizerPixelSize([string]$Name) {
    switch($Name){
        'Monolith (12x4)'{return [PSCustomObject]@{Width=12;Height=4;Class='minimum generation cost'}}
        'Mega Blocks (16x5)'{return [PSCustomObject]@{Width=16;Height=5;Class='extremely low generation cost'}}
        'Giant Blocks (20x6)'{return [PSCustomObject]@{Width=20;Height=6;Class='very low generation cost'}}
        'Huge Blocks (28x8)'{return [PSCustomObject]@{Width=28;Height=8;Class='low generation cost'}}
        'Chunky (48x12)'{return [PSCustomObject]@{Width=48;Height=12;Class='moderate detail'}}
        'Fine (64x18)'{return [PSCustomObject]@{Width=64;Height=18;Class='fine detail'}}
        'Extra Fine (96x24)'{return [PSCustomObject]@{Width=96;Height=24;Class='high detail'}}
        'Ultra Fine (128x32)'{return [PSCustomObject]@{Width=128;Height=32;Class='very high detail'}}
        'Microscopic (160x40)'{return [PSCustomObject]@{Width=160;Height=40;Class='extreme detail'}}
        'Maximum Detail (192x48)'{return [PSCustomObject]@{Width=192;Height=48;Class='maximum supported detail'}}
        default{return [PSCustomObject]@{Width=40;Height=10;Class='default balanced detail'}}
    }
}

function Update-VisualizerResolutionInfo {
    $r=Get-VisualizerPixelSize ([string]$chunk.SelectedItem)
    $pixels=[int]$r.Width*[int]$r.Height
    $fps=$(if([string]$vizFps.SelectedItem -match '^60'){60}else{30})
    $samplesPerSecond=$pixels*$fps
    $relative=[int][Math]::Round(($samplesPerSecond/12000.0)*100)
    $visualCost.Text="Generated source: $($r.Width)x$($r.Height) = $pixels pixels/frame x $fps FPS = $samplesPerSecond samples/sec ($relative% of Default 40x10 @ 30).  Profile: $($r.Class)."
}

function Apply-VisualizerPreset {
    if($script:ApplyingVisualizerPreset){return}
    $script:ApplyingVisualizerPreset=$true
    try{
        switch([string]$vizPreset.SelectedItem){
            'Default'{$activity.SelectedItem='Active';$opacityPct.Value=30;$chunk.SelectedItem='Extra Chunky (40x10)';$vizLength.SelectedItem='Wide';$vizColorMode.SelectedItem='Solid';$vizSolid.SelectedItem='Gray';$gradientOrientation.SelectedItem='Horizontal';$vizDirection.SelectedItem='Normal';$vizLayer.SelectedItem='Behind text';$vizShape.SelectedItem='Spectrum';$vizAnchor.SelectedItem='Source';$vizSpacing.SelectedItem='None';$vizPeakGlow.SelectedItem='Off';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='30 FPS';$vizHighTrim.Value=20}
            'Monolith Efficiency'{$activity.SelectedItem='Normal';$opacityPct.Value=30;$chunk.SelectedItem='Monolith (12x4)';$vizLength.SelectedItem='Medium';$vizColorMode.SelectedItem='Solid';$vizSolid.SelectedItem='Gray';$vizShape.SelectedItem='Spectrum';$vizAnchor.SelectedItem='Source';$vizSpacing.SelectedItem='None';$vizPeakGlow.SelectedItem='Off';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='30 FPS';$vizHighTrim.Value=28}
            'Low Overhead Blocks'{$activity.SelectedItem='Normal';$opacityPct.Value=28;$chunk.SelectedItem='Giant Blocks (20x6)';$vizLength.SelectedItem='Medium';$vizColorMode.SelectedItem='Solid';$vizSolid.SelectedItem='Gray';$vizShape.SelectedItem='Spectrum';$vizAnchor.SelectedItem='Source';$vizSpacing.SelectedItem='None';$vizPeakGlow.SelectedItem='Off';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='30 FPS';$vizHighTrim.Value=25}
            'Broadcast'{$activity.SelectedItem='Active';$opacityPct.Value=38;$chunk.SelectedItem='Chunky (48x12)';$vizLength.SelectedItem='Wide';$vizColorMode.SelectedItem='Gradient';$vizGradient.SelectedItem='Sunset';$gradientOrientation.SelectedItem='Horizontal';$vizDirection.SelectedItem='Normal';$vizLayer.SelectedItem='Behind text';$vizShape.SelectedItem='Spectrum';$vizAnchor.SelectedItem='Bottom';$vizSpacing.SelectedItem='Light';$vizPeakGlow.SelectedItem='Subtle';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='30 FPS';$vizHighTrim.Value=20}
            'Smooth 60 FPS'{$activity.SelectedItem='Active';$opacityPct.Value=34;$chunk.SelectedItem='Fine (64x18)';$vizLength.SelectedItem='Wide';$vizColorMode.SelectedItem='Solid';$vizSolid.SelectedItem='Cyan';$vizShape.SelectedItem='Spectrum';$vizAnchor.SelectedItem='Bottom';$vizSpacing.SelectedItem='Light';$vizPeakGlow.SelectedItem='Subtle';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='60 FPS';$vizHighTrim.Value=20}
            'Signal Analyzer'{$activity.SelectedItem='Active';$opacityPct.Value=42;$chunk.SelectedItem='Maximum Detail (192x48)';$vizLength.SelectedItem='Extra Wide';$vizColorMode.SelectedItem='Gradient';$vizGradient.SelectedItem='Ocean';$gradientOrientation.SelectedItem='Vertical';$vizDirection.SelectedItem='Normal';$vizLayer.SelectedItem='Above text';$vizShape.SelectedItem='Oscilloscope';$vizAnchor.SelectedItem='Center';$vizSpacing.SelectedItem='None';$vizPeakGlow.SelectedItem='Subtle';$vizFrequency.SelectedItem='Linear';$vizFps.SelectedItem='60 FPS';$vizHighTrim.Value=0}
            'Neon Motion'{$activity.SelectedItem='Punchy';$opacityPct.Value=48;$chunk.SelectedItem='Extra Fine (96x24)';$vizLength.SelectedItem='Extra Wide';$vizColorMode.SelectedItem='Gradient';$vizGradient.SelectedItem='Ocean';$gradientOrientation.SelectedItem='Horizontal';$vizDirection.SelectedItem='Mirrored';$vizLayer.SelectedItem='Above text';$vizShape.SelectedItem='Particle Field';$vizAnchor.SelectedItem='Center';$vizSpacing.SelectedItem='Light';$vizPeakGlow.SelectedItem='Strong';$vizFrequency.SelectedItem='Logarithmic';$vizFps.SelectedItem='60 FPS';$vizHighTrim.Value=16}
        }
    }finally{$script:ApplyingVisualizerPreset=$false}
    Update-Dependencies;Update-VisualizerResolutionInfo;Update-Preview
}

function Apply-PerformancePreset {
    if($script:ApplyingPerformancePreset){return}
    $script:ApplyingPerformancePreset=$true
    try{
        switch([string]$performancePreset.SelectedItem){
            'Default'{$performance.SelectedItem='Balanced (2 workers)';$browserFps.SelectedItem='Auto';$loudness.Checked=$true;$prefetch.Value=4;$videoPreference.SelectedItem='Prefer selected maximum';$audioQuality.SelectedItem='Best available';$audioPreference.SelectedItem='Prefer selected maximum'}
            'Gaming'{$performance.SelectedItem='Gaming / Lowest overhead (1 worker)';$browserFps.SelectedItem='Auto';$loudness.Checked=$true;$prefetch.Value=2;$videoPreference.SelectedItem='Prefer lowest compatible';$audioQuality.SelectedItem='High (~160 kbps)';$audioPreference.SelectedItem='Prefer selected maximum'}
            'Rapid Cache'{$performance.SelectedItem='Fast caching (4 workers)';$browserFps.SelectedItem='Auto';$loudness.Checked=$true;$prefetch.Value=8;$videoPreference.SelectedItem='Prefer selected maximum';$audioQuality.SelectedItem='Best available';$audioPreference.SelectedItem='Prefer selected maximum'}
            'Deep Cache'{$performance.SelectedItem='Maximum caching (8 workers)';$browserFps.SelectedItem='Auto';$loudness.Checked=$true;$prefetch.Value=20;$videoPreference.SelectedItem='Prefer selected maximum';$audioQuality.SelectedItem='Best available';$audioPreference.SelectedItem='Prefer selected maximum'}
        }
    }finally{$script:ApplyingPerformancePreset=$false}
    Update-Preview
}

function Apply-DirectorPreset {
    if($script:ApplyingDirectorPreset){return}
    if([string]$directorPreset.SelectedItem -eq 'Custom'){return}
    $script:ApplyingDirectorPreset=$true
    try{
        # Establish complete values first so switching from an extravagant preset
        # back to a restrained one never leaves an expensive hidden toggle behind.
        $directorOn.Checked=$true;$directorTheme.SelectedItem='Classic';$directorTimeline.SelectedItem='Broadcast Rotation';$directorMotion.SelectedItem='Subtle';$directorPalette.SelectedItem='Track identity';$statsDetail.SelectedItem='Broadcast';$directorVizShape.SelectedItem='Use global'
        $commentOn.Checked=$false;$commentChars.Value=220;$commentFilter.SelectedItem='Basic safety';$telemetryOn.Checked=$false;$probeOn.Checked=$false;$historyOn.Checked=$false;$historyMax.Value=100
        switch([string]$directorPreset.SelectedItem){
            'Default'{$directorOn.Checked=$false}
            'Pirate Radio'{$directorTheme.SelectedItem='Pirate Radio';$directorTimeline.SelectedItem='Rapid Rotation';$directorMotion.SelectedItem='Full';$commentOn.Checked=$true;$historyOn.Checked=$true}
            'Culture Desk'{$directorTheme.SelectedItem='Record Store';$directorTimeline.SelectedItem='Cinematic';$directorMotion.SelectedItem='Subtle';$commentOn.Checked=$true;$historyOn.Checked=$true}
            'Control Room'{$directorTheme.SelectedItem='Control Room';$directorPalette.SelectedItem='Theme fixed';$statsDetail.SelectedItem='Stats for Nerds';$telemetryOn.Checked=$true;$probeOn.Checked=$true;$historyOn.Checked=$true}
            'Full Science'{$directorTheme.SelectedItem='Cyberpunk Lab';$directorTimeline.SelectedItem='Rapid Rotation';$directorMotion.SelectedItem='Full';$statsDetail.SelectedItem='Completely Unhinged';$directorVizShape.SelectedItem='Particle Field';$commentOn.Checked=$true;$telemetryOn.Checked=$true;$probeOn.Checked=$true;$historyOn.Checked=$true}
        }
    }finally{$script:ApplyingDirectorPreset=$false}
    Update-Dependencies;Update-Preview
}

function Set-OutputRow($row,[bool]$enabled,[string]$name,[string]$modules,[string]$layout,[string]$theme,[int]$width,[int]$height) {
    $row.Enabled.Checked=$enabled;$row.Name.Text=$name;$row.Modules.Text=$modules;$row.Layout.SelectedItem=$layout;$row.Theme.SelectedItem=$theme;$row.Width.Value=$width;$row.Height.Value=$height
}

function Apply-OutputsPreset {
    if($script:ApplyingOutputsPreset){return}
    if([string]$outputsPreset.SelectedItem -eq 'Custom'){return}
    $script:ApplyingOutputsPreset=$true
    try{
        $rows=@($outputControls)
        switch([string]$outputsPreset.SelectedItem){
            'Default'{
                Set-OutputRow ($rows[0]) $true 'Now Playing' 'artwork,video,title,channel,visualizer' 'Broadcast Strip' 'Global' 2560 90
                Set-OutputRow ($rows[1]) $false 'Information' 'stats,technical,progress' 'Cards' 'Global' 900 260
                Set-OutputRow ($rows[2]) $false 'Culture' 'comment,history,upnext' 'Stack' 'Global' 900 420
                Set-OutputRow ($rows[3]) $false 'Engineering' 'technical,pipeline,mission' 'Terminal' 'Archive Terminal' 900 420
                Set-OutputRow ($rows[4]) $false 'Director Timeline' 'artwork,video,title,channel,visualizer,comment,stats,technical,progress,history,upnext,mission' 'Timeline' 'Global' 1920 1080
                Set-OutputRow ($rows[5]) $false 'Custom' 'title,channel' 'Horizontal' 'Global' 900 180
            }
            'Minimal'{
                Set-OutputRow ($rows[0]) $true 'Now Playing' 'title,channel' 'Horizontal' 'Global' 900 180
                for($i=1;$i -lt 6;$i++){Set-OutputRow ($rows[$i]) $false ("Output "+($i+1)) 'title,channel' 'Horizontal' 'Global' 900 180}
            }
            'Split Essentials'{
                Set-OutputRow ($rows[0]) $true 'Artwork' 'artwork' 'Single' 'Global' 320 180
                Set-OutputRow ($rows[1]) $true 'Video' 'video' 'Single' 'Global' 320 180
                Set-OutputRow ($rows[2]) $true 'Title Card' 'title,channel' 'Stack' 'Global' 900 180
                Set-OutputRow ($rows[3]) $true 'Visualizer' 'visualizer' 'Single' 'Global' 900 180
                Set-OutputRow ($rows[4]) $true 'Culture' 'comment,history,upnext' 'Stack' 'Global' 900 420
                Set-OutputRow ($rows[5]) $true 'Stats Lab' 'stats,technical,pipeline,mission' 'Cards' 'Control Room' 1200 420
            }
            'Broadcast Desk'{
                Set-OutputRow ($rows[0]) $true 'Now Playing' 'artwork,video,title,channel,visualizer' 'Broadcast Strip' 'Global' 2560 90
                Set-OutputRow ($rows[1]) $true 'Information' 'stats,technical,progress' 'Cards' 'Global' 900 260
                Set-OutputRow ($rows[2]) $true 'Culture' 'comment,history,upnext' 'Stack' 'Global' 900 420
                Set-OutputRow ($rows[3]) $true 'Engineering' 'technical,pipeline,mission' 'Terminal' 'Archive Terminal' 900 420
                Set-OutputRow ($rows[4]) $false 'Director Timeline' 'artwork,video,title,channel,visualizer,comment,stats,technical,progress,history,upnext,mission' 'Timeline' 'Global' 1920 1080
                Set-OutputRow ($rows[5]) $false 'Custom' 'title,channel' 'Horizontal' 'Global' 900 180
            }
            'Full Studio'{
                Set-OutputRow ($rows[0]) $true 'Now Playing' 'artwork,video,title,channel,visualizer' 'Broadcast Strip' 'Global' 2560 90
                Set-OutputRow ($rows[1]) $true 'Telemetry Wall' 'stats,technical,pipeline,mission' 'Cards' 'Control Room' 1200 500
                Set-OutputRow ($rows[2]) $true 'Culture Desk' 'comment,history,upnext' 'Stack' 'Record Store' 900 500
                Set-OutputRow ($rows[3]) $true 'Engineering' 'technical,pipeline,mission' 'Terminal' 'Archive Terminal' 900 420
                Set-OutputRow ($rows[4]) $true 'Director Timeline' 'artwork,video,title,channel,visualizer,comment,stats,technical,progress,history,upnext,mission' 'Timeline' 'Global' 1920 1080
                Set-OutputRow ($rows[5]) $true 'Mission Control' 'upnext,progress,stats,mission' 'Horizontal' 'Spacecraft' 1600 260
            }
        }
    }finally{$script:ApplyingOutputsPreset=$false}
    Update-Preview
}

function Get-UiConfig {
    $o=Get-YomiConfig
    $o.general_preset=[string]$generalPreset.SelectedItem; $o.app_mode=[string]$mode.SelectedItem; $o.player_video_quality=[string]$playerQuality.SelectedItem
    $o.video_preference=[string]$videoPreference.SelectedItem; $o.audio_quality=[string]$audioQuality.SelectedItem; $o.audio_preference=[string]$audioPreference.SelectedItem
    $o.overlay_preset=[string]$overlayPreset.SelectedItem; $o.canvas_preset=[string]$canvasPreset.SelectedItem; $o.canvas_width=[int]$canvasW.Value; $o.canvas_height=[int]$canvasH.Value; $o.corner=[string]$corner.SelectedItem
    $o.media_size_preset=[string]$mediaPreset.SelectedItem; $o.media_width=[int]$mediaW.Value; $o.media_height=[int]$mediaH.Value; $o.video_zoom=[Math]::Round(([double]$videoZoom.Value/100.0),2)
    $o.overlay_video_quality=[string]$overlayVideoQuality.SelectedItem; $o.video_fps=[string]$videoFps.SelectedItem; $o.video_cache_limit_mb=[int]$videoCacheLimit.Value
    $o.artwork_enabled=[bool]$art.Checked; $o.smart_artwork_crop=[bool]$smartCrop.Checked; $o.video_enabled=[bool]$video.Checked; $o.title_enabled=[bool]$titleCheck.Checked; $o.channel_enabled=[bool]$channel.Checked; $o.visualizer_enabled=[bool]$viz.Checked
    $o.style_preset=[string]$stylePreset.SelectedItem; $o.text_font=[string]$font.SelectedItem; $o.text_color=Map-Color ([string]$textColor.SelectedItem); $o.outline_color=Map-Color ([string]$outlineColor.SelectedItem); $o.text_outline=[int]$outlinePx.Value; $o.text_opacity=[Math]::Round(([double]$textOpacity.Value/100.0),2); $o.text_size=[int]$textSize.Value; $o.text_alignment=[string]$textAlign.SelectedItem; $o.title_channel_spacing=[string]$textSpacing.SelectedItem; $o.text_glow=[bool]$glow.Checked
    $o.media_border_enabled=[bool]$borderOn.Checked; $o.media_border_px=[int]$borderPx.Value; $o.media_border_color=Map-Color ([string]$borderColor.SelectedItem); $o.media_corner_style=[string]$cornerStyle.SelectedItem
    $o.visualizer_preset=[string]$vizPreset.SelectedItem; $o.visualizer_activity=[string]$activity.SelectedItem; $o.visualizer_opacity=[Math]::Round(([double]$opacityPct.Value/100.0),2)
    $vizPixels=Get-VisualizerPixelSize ([string]$chunk.SelectedItem);$o.visualizer_internal_width=[int]$vizPixels.Width;$o.visualizer_internal_height=[int]$vizPixels.Height
    switch([string]$vizLength.SelectedItem){'Short'{$o.visualizer_length_multiplier=2.0}'Medium'{$o.visualizer_length_multiplier=3.0}'Extra Wide'{$o.visualizer_length_multiplier=6.0}default{$o.visualizer_length_multiplier=4.0}}
    $o.visualizer_color_mode=[string]$vizColorMode.SelectedItem; $o.visualizer_solid_color=Map-Color ([string]$vizSolid.SelectedItem); $o.visualizer_gradient_preset=[string]$vizGradient.SelectedItem; $o.visualizer_gradient_orientation=[string]$gradientOrientation.SelectedItem; $o.visualizer_direction=[string]$vizDirection.SelectedItem; $o.visualizer_layer=[string]$vizLayer.SelectedItem
    $o.visualizer_shape=[string]$vizShape.SelectedItem; $o.visualizer_vertical_anchor=[string]$vizAnchor.SelectedItem; $o.visualizer_bar_spacing=[string]$vizSpacing.SelectedItem; $o.visualizer_peak_glow=[string]$vizPeakGlow.SelectedItem; $o.visualizer_frequency_scale=[string]$vizFrequency.SelectedItem; $o.visualizer_high_frequency_trim=[int]$vizHighTrim.Value; $o.visualizer_fps=[string]$vizFps.SelectedItem
    $o.performance_preset=[string]$performancePreset.SelectedItem; $o.browser_fps_mode=[string]$browserFps.SelectedItem; $o.loudness_normalization=[bool]$loudness.Checked; $o.prefetch_ahead=[int]$prefetch.Value; $o.video_prefetch_ahead=[int]$prefetch.Value
    $o.director_preset=[string]$directorPreset.SelectedItem; $o.director_mode=[bool]$directorOn.Checked; $o.director_theme=[string]$directorTheme.SelectedItem; $o.director_timeline=[string]$directorTimeline.SelectedItem; $o.director_motion=[string]$directorMotion.SelectedItem; $o.director_palette=[string]$directorPalette.SelectedItem; $o.director_visualizer_shape=[string]$directorVizShape.SelectedItem; $o.stats_detail=[string]$statsDetail.SelectedItem
    $o.featured_comment_enabled=[bool]$commentOn.Checked; $o.comment_max_chars=[int]$commentChars.Value; $o.comment_filter_mode=[string]$commentFilter.SelectedItem
    $o.telemetry_enabled=[bool]$telemetryOn.Checked; $o.telemetry_probe_enabled=[bool]$probeOn.Checked
    $o.history_enabled=[bool]$historyOn.Checked; $o.history_max_entries=[int]$historyMax.Value
    $outs=@()
    foreach($row in $outputControls) {
        $outs += [PSCustomObject]@{
            id=[int]$row.Id
            enabled=[bool]$row.Enabled.Checked
            name=[string]$row.Name.Text.Trim()
            modules=[string]$row.Modules.Text.Trim().ToLowerInvariant()
            layout=[string]$row.Layout.SelectedItem
            theme=[string]$row.Theme.SelectedItem
            width=[int]$row.Width.Value
            height=[int]$row.Height.Value
        }
    }
    $o.outputs_preset=[string]$outputsPreset.SelectedItem;$o.director_outputs=$outs
    switch([string]$performance.SelectedItem){'Balanced (2 workers)'{$o.performance_mode='Balanced';$o.cache_workers=2;$o.cache_priority='idle'}'Fast caching (4 workers)'{$o.performance_mode='Fast caching';$o.cache_workers=4;$o.cache_priority='below'}'Maximum caching (8 workers)'{$o.performance_mode='Maximum caching';$o.cache_workers=8;$o.cache_priority='below'}default{$o.performance_mode='Gaming / Lowest overhead';$o.cache_workers=1;$o.cache_priority='idle'}}
    return $o
}

function Update-QualityWarning {
    $q=[string]$overlayVideoQuality.SelectedItem
    $show=([string]$mode.SelectedItem -eq 'Streamer / OBS') -and $video.Checked -and ($q -eq '720p' -or $q -eq 'Best compatible')
    $qualityWarning.Visible=$show
    if($show){$obsHint.Location=New-Object System.Drawing.Point(18,360)}
    else{$obsHint.Location=New-Object System.Drawing.Point(18,292)}
}

function Update-Dependencies {
    $streamer=([string]$mode.SelectedItem -eq 'Streamer / OBS')
    $ff=Test-YomiComponent 'ffmpeg'
    $playerQuality.Enabled=(-not $streamer)
    foreach($c in @($overlayPreset,$canvasPreset,$canvasW,$canvasH,$corner,$mediaPreset,$mediaW,$mediaH,$videoZoom,$overlayVideoQuality,$videoFps,$videoCacheLimit,$art,$video,$titleCheck,$channel,$font,$textColor,$outlineColor,$outlinePx,$textOpacity,$textSize,$textAlign,$textSpacing,$glow,$borderOn,$borderPx,$borderColor,$cornerStyle,$vizPreset,$activity,$opacityPct,$chunk,$vizLength,$vizColorMode,$vizSolid,$vizGradient,$gradientOrientation,$vizDirection,$vizLayer,$vizShape,$vizAnchor,$vizSpacing,$vizPeakGlow,$vizFrequency,$vizFps,$vizHighTrim,$browserFps)){ $c.Enabled=$streamer }
    $viz.Enabled=($streamer -and $ff)
    foreach($c in @($vizPreset,$activity,$opacityPct,$chunk,$vizLength,$vizColorMode,$vizSolid,$vizGradient,$gradientOrientation,$vizDirection,$vizLayer,$vizShape,$vizAnchor,$vizSpacing,$vizPeakGlow,$vizFrequency,$vizFps,$vizHighTrim)) { $c.Enabled=($streamer -and $ff) }
    $vizActive=($streamer -and $ff)
    $colorMode=[string]$vizColorMode.SelectedItem
    $vizSolid.Enabled=($vizActive -and $colorMode -eq 'Solid')
    $vizGradient.Enabled=($vizActive -and $colorMode -eq 'Gradient')
    $gradientOrientation.Enabled=($vizActive -and ($colorMode -eq 'Gradient' -or $colorMode -eq 'Rainbow'))
    $smartCrop.Enabled=($streamer -and $ff)
    $loudness.Enabled=$ff
    $directorOn.Enabled=$streamer
    $directorPreset.Enabled=$streamer
    $directorActive=($streamer -and $directorOn.Checked)
    foreach($c in @($directorTheme,$directorTimeline,$directorMotion,$directorPalette,$directorVizShape,$statsDetail,$commentOn,$telemetryOn,$historyOn,$copySources,$openObsGuide)){ $c.Enabled=$directorActive }
    $commentChars.Enabled=($directorActive -and $commentOn.Checked)
    $commentFilter.Enabled=($directorActive -and $commentOn.Checked)
    $probeOn.Enabled=($directorActive -and $telemetryOn.Checked -and $ff)
    $historyMax.Enabled=($directorActive -and $historyOn.Checked)
    foreach($row in $outputControls) {
        foreach($c in @($row.Enabled,$row.Name,$row.Modules,$row.Layout,$row.Theme,$row.Width,$row.Height)) { $c.Enabled=$directorActive }
    }
    $outputsPreset.Enabled=$directorActive
    $copyOverlay.Enabled=$streamer; $obsSetup.Enabled=$streamer
    Update-QualityWarning
}

function Update-Components {
    $mp=Get-YomiComponentInfo 'mpv'; $yt=Get-YomiComponentInfo 'ytdlp'; $de=Get-YomiComponentInfo 'deno'; $ff=Get-YomiComponentInfo 'ffmpeg'
    function Line($label,$x,$required){if($x.Installed){$v=$x.Version;if($v.Length -gt 55){$v=$v.Substring(0,55)};return "$label : INSTALLED  |  $($x.SizeMB) MB  |  $v"}elseif($required){return "$label : MISSING - repair/reinstall YOMI"}else{return "$label : Not installed"}}
    $compStatus.Text=(Line 'mpv (core)' $mp $true)+"`r`n"+(Line 'yt-dlp (core)' $yt $true)+"`r`n"+(Line 'Deno / YouTube Compatibility' $de $false)+"`r`n"+(Line 'FFmpeg Media Tools' $ff $false)+"`r`n`r`nOptional components can be added or removed later."
    if($de.Installed){$denoBtn.Text='REMOVE DENO'}else{$denoBtn.Text='INSTALL DENO'}
    if($ff.Installed){$ffmpegBtn.Text='REMOVE FFMPEG MEDIA TOOLS'}else{$ffmpegBtn.Text='INSTALL FFMPEG MEDIA TOOLS'}
    Update-Dependencies
}

function Preview-AlphaColor([System.Drawing.Color]$c,[double]$opacity) {
    $a=[Math]::Max(0,[Math]::Min(255,[int][Math]::Round(255*$opacity)))
    return [System.Drawing.Color]::FromArgb($a,$c.R,$c.G,$c.B)
}

function Preview-MixColor([System.Drawing.Color]$a,[System.Drawing.Color]$b,[double]$t) {
    $t=[Math]::Max(0,[Math]::Min(1,$t))
    return [System.Drawing.Color]::FromArgb(
        255,
        [int][Math]::Round($a.R+(($b.R-$a.R)*$t)),
        [int][Math]::Round($a.G+(($b.G-$a.G)*$t)),
        [int][Math]::Round($a.B+(($b.B-$a.B)*$t))
    )
}

function Preview-VizColor($u,[double]$t) {
    if([string]$u.visualizer_color_mode -eq 'Rainbow') {
        $colors=@('#FF6B6B','#FFD166','#7BE495','#70E1F5','#72A7FF','#C4A7FF','#FF86C8')
        $p=$t*($colors.Count-1)
        $i=[Math]::Min($colors.Count-2,[Math]::Max(0,[int][Math]::Floor($p)))
        $a=Hex-Color $colors[$i]
        $b=Hex-Color $colors[$i+1]
        return (Preview-MixColor $a $b ($p-$i))
    }

    if([string]$u.visualizer_color_mode -eq 'Gradient') {
        $sets=@{
            'Sunset'=@('#FF6B6B','#FFA552','#C4A7FF')
            'Ocean'=@('#72A7FF','#70E1F5','#9B7BFF')
            'Pastel'=@('#FF86C8','#C4A7FF','#70E1F5')
            'Fire'=@('#FF6B6B','#FFA552','#FFD166')
            'Forest'=@('#2E7D32','#7BE495','#FFD166')
            'Mono'=@('#F2F0E8','#8A8A84','#252525')
        }
        $set=$sets[[string]$u.visualizer_gradient_preset]
        if($null -eq $set){$set=$sets['Sunset']}
        if($t -lt 0.5) {
            $a=Hex-Color $set[0]
            $b=Hex-Color $set[1]
            return (Preview-MixColor $a $b ($t*2))
        }
        $a=Hex-Color $set[1]
        $b=Hex-Color $set[2]
        return (Preview-MixColor $a $b (($t-0.5)*2))
    }

    return (Hex-Color ([string]$u.visualizer_solid_color))
}

function Preview-DrawText(
    [System.Drawing.Graphics]$g,
    [string]$text,
    [System.Drawing.Font]$font,
    [System.Drawing.Rectangle]$rect,
    [System.Drawing.Color]$textColor,
    [System.Drawing.Color]$outlineColor,
    [int]$outlinePx,
    [bool]$glow,
    [string]$alignment
) {
    $fmt=New-Object System.Drawing.StringFormat
    if($alignment -eq 'Right'){$fmt.Alignment=[System.Drawing.StringAlignment]::Far}
    elseif($alignment -eq 'Center'){$fmt.Alignment=[System.Drawing.StringAlignment]::Center}
    else{$fmt.Alignment=[System.Drawing.StringAlignment]::Near}
    $fmt.LineAlignment=[System.Drawing.StringAlignment]::Near
    $fmt.Trimming=[System.Drawing.StringTrimming]::EllipsisCharacter
    $fmt.FormatFlags=[System.Drawing.StringFormatFlags]::NoWrap

    if($glow) {
        $gb=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(50,$textColor.R,$textColor.G,$textColor.B))
        foreach($dx in @(-3,0,3)) {
            foreach($dy in @(-3,0,3)) {
                if($dx -eq 0 -and $dy -eq 0){continue}
                $r=New-Object System.Drawing.Rectangle($rect.X+$dx,$rect.Y+$dy,$rect.Width,$rect.Height)
                $g.DrawString($text,$font,$gb,$r,$fmt)
            }
        }
        $gb.Dispose()
    }

    if($outlinePx -gt 0) {
        $ob=New-Object System.Drawing.SolidBrush($outlineColor)
        foreach($dx in @(-$outlinePx,0,$outlinePx)) {
            foreach($dy in @(-$outlinePx,0,$outlinePx)) {
                if($dx -eq 0 -and $dy -eq 0){continue}
                $r=New-Object System.Drawing.Rectangle($rect.X+$dx,$rect.Y+$dy,$rect.Width,$rect.Height)
                $g.DrawString($text,$font,$ob,$r,$fmt)
            }
        }
        $ob.Dispose()
    }

    $tb=New-Object System.Drawing.SolidBrush($textColor)
    $g.DrawString($text,$font,$tb,$rect,$fmt)
    $tb.Dispose()
    $fmt.Dispose()
}

function Update-Preview {
    try{
        $u=Get-UiConfig
        $m=Get-YomiLayoutMetrics $u
        $previewInfo.Text="Overlay close-up  |  Canvas $($m.CanvasWidth)x$($m.CanvasHeight), $($u.corner)  |  Browser $($m.OverlayWidth)x$($m.OverlayHeight) @ $($m.BrowserFps) FPS`r`nMedia $($m.MediaWidth)x$($m.MediaHeight)  |  Font $($u.text_font), $($u.text_size)px  |  $($u.performance_mode), $($u.cache_workers) workers`r`nPreview uses generic sample content only. It never reads your playlist, current track or cache."
        $preview.Invalidate()
    }catch{}
}

$preview.Add_Paint({
    param($sender,$e)

    try{
        $u=Get-UiConfig
        $m=Get-YomiLayoutMetrics $u
        $g=$e.Graphics
        $g.SmoothingMode=[System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit

        $bg=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(20,20,20))
        $g.FillRectangle($bg,0,0,$sender.Width,$sender.Height)
        $bg.Dispose()

        # Transparent-canvas checkerboard.
        $cell=18
        $a=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(39,39,39))
        $b=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(48,48,48))
        for($yy=28;$yy -lt 270;$yy+=$cell) {
            for($xx=18;$xx -lt ($sender.Width-18);$xx+=$cell) {
                $index=(([int](($xx-18)/$cell))+([int](($yy-28)/$cell))) % 2
                if($index -eq 0){$g.FillRectangle($a,$xx,$yy,$cell,$cell)}
                else{$g.FillRectangle($b,$xx,$yy,$cell,$cell)}
            }
        }
        $a.Dispose()
        $b.Dispose()

        $capFont=New-Object System.Drawing.Font('Segoe UI Semibold',9)
        $capBrush=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Gainsboro)
        $g.DrawString('OVERLAY CLOSE-UP',$capFont,$capBrush,18,6)

        if([string]$u.app_mode -ne 'Streamer / OBS') {
            $f1=New-Object System.Drawing.Font('Segoe UI Semibold',18)
            $f2=New-Object System.Drawing.Font('Segoe UI',10)
            $w=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
            $d=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Silver)
            $g.DrawString('Player mode',$f1,$w,42,96)
            $g.DrawString('OBS overlay disabled — configure player-video quality in General.',$f2,$d,42,138)
            $w.Dispose();$d.Dispose();$f1.Dispose();$f2.Dispose();$capBrush.Dispose();$capFont.Dispose()
            return
        }

        $mh=[Math]::Max(20,[double]$m.MediaHeight)
        $mw=[Math]::Max(20,[double]$m.MediaWidth)
        $scale=[Math]::Min(2.0,[Math]::Max(0.50,126.0/$mh))
        $pmh=[int][Math]::Round($mh*$scale)
        $pmw=[int][Math]::Round($mw*$scale)

        $borderPx=0
        if([bool]$u.media_border_enabled){
            $borderPx=[Math]::Max(1,[int][Math]::Round([double]$u.media_border_px*$scale))
        }

        $artOn=[bool]$u.artwork_enabled
        $vidOn=[bool]$u.video_enabled
        $vizOn=[bool]$u.visualizer_enabled
        $right=([string]$u.corner).EndsWith('Right')

        $count=0
        if($artOn){$count++}
        if($vidOn){$count++}
        $mediaExtent=$count*$pmw
        if($artOn -and $vidOn -and $borderPx -gt 0){$mediaExtent-=$borderPx}

        $stripY=[Math]::Max(54,[int](145-($pmh/2)))
        if(($stripY+$pmh) -gt 258){$stripY=258-$pmh}

        $margin=34
        $gap=[Math]::Max(7,[int][Math]::Round(14*$scale))
        $textWidth=[Math]::Max(220,$sender.Width-(2*$margin)-$mediaExtent-$gap-20)

        if(-not $right) {
            $mediaX=$margin
            $textX=$mediaX+$mediaExtent+$gap
            $mediaEdge=$mediaX+$mediaExtent
        } else {
            $mediaX=$sender.Width-$margin-$mediaExtent
            $textX=$mediaX-$gap-$textWidth
            $mediaEdge=$mediaX
        }

        $borderColor=Hex-Color ([string]$u.media_border_color)
        $artFill=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(68,78,96))
        $videoFill=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(40,56,56))
        $borderBrush=New-Object System.Drawing.SolidBrush($borderColor)

        # Media placeholders with the configured frame visibly on top.
        if(-not $right) {
            $x=$mediaX
            if($artOn) {
                $g.FillRectangle($artFill,$x,$stripY,$pmw,$pmh)
                if($borderPx -gt 0){
                    $pen=New-Object System.Drawing.Pen($borderColor,$borderPx)
                    $g.DrawRectangle($pen,$x,$stripY,$pmw-1,$pmh-1)
                    $pen.Dispose()
                }
                $x+=$pmw
                if($vidOn -and $borderPx -gt 0){$x-=$borderPx}
            }
            if($vidOn) {
                $g.FillRectangle($videoFill,$x,$stripY,$pmw,$pmh)
                if($borderPx -gt 0){
                    $pen=New-Object System.Drawing.Pen($borderColor,$borderPx)
                    $g.DrawRectangle($pen,$x,$stripY,$pmw-1,$pmh-1)
                    $pen.Dispose()
                }
            }
        } else {
            $x=$mediaX+$mediaExtent
            if($artOn) {
                $x-=$pmw
                $g.FillRectangle($artFill,$x,$stripY,$pmw,$pmh)
                if($borderPx -gt 0){
                    $pen=New-Object System.Drawing.Pen($borderColor,$borderPx)
                    $g.DrawRectangle($pen,$x,$stripY,$pmw-1,$pmh-1)
                    $pen.Dispose()
                }
                if($vidOn -and $borderPx -gt 0){$x+=$borderPx}
            }
            if($vidOn) {
                $x-=$pmw
                $g.FillRectangle($videoFill,$x,$stripY,$pmw,$pmh)
                if($borderPx -gt 0){
                    $pen=New-Object System.Drawing.Pen($borderColor,$borderPx)
                    $g.DrawRectangle($pen,$x,$stripY,$pmw-1,$pmh-1)
                    $pen.Dispose()
                }
            }
        }

        $artFill.Dispose();$videoFill.Dispose();$borderBrush.Dispose()

        # Small neutral labels so the two media modules are obvious.
        $moduleFont=New-Object System.Drawing.Font('Segoe UI Semibold',[single][Math]::Max(8,[Math]::Min(13,$pmh*0.13)))
        $moduleBrush=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(205,245,245,245))
        if(-not $right) {
            $x=$mediaX
            if($artOn){$g.DrawString('ART',$moduleFont,$moduleBrush,$x+8,$stripY+8);$x+=$pmw;if($vidOn -and $borderPx -gt 0){$x-=$borderPx}}
            if($vidOn){$g.DrawString('VIDEO',$moduleFont,$moduleBrush,$x+8,$stripY+8)}
        } else {
            $x=$mediaX+$mediaExtent
            if($artOn){$x-=$pmw;$g.DrawString('ART',$moduleFont,$moduleBrush,$x+8,$stripY+8);if($vidOn -and $borderPx -gt 0){$x+=$borderPx}}
            if($vidOn){$x-=$pmw;$g.DrawString('VIDEO',$moduleFont,$moduleBrush,$x+8,$stripY+8)}
        }
        $moduleBrush.Dispose();$moduleFont.Dispose()

        # Visualizer: first visible bar starts at the media edge, independently
        # of text padding. This mirrors the real overlay architecture.
        $drawViz={
            if(-not $vizOn){return}
            $barCount=28
            $vizWidth=[Math]::Min([Math]::Max(120,[int](260*$scale)),$textWidth+$gap)
            $barStep=[Math]::Max(3,[int]($vizWidth/$barCount))
            $barW=[Math]::Max(2,$barStep-2)
            if([string]$u.visualizer_bar_spacing -eq 'Light'){$barW=[Math]::Max(2,$barStep-3)}
            elseif([string]$u.visualizer_bar_spacing -eq 'Wide'){$barW=[Math]::Max(1,[int][Math]::Floor($barStep/2))}
            $shape=[string]$u.visualizer_shape
            $anchor=[string]$u.visualizer_vertical_anchor

            for($i=0;$i -lt $barCount;$i++) {
                $logical=$i
                if([string]$u.visualizer_direction -eq 'Mirrored'){$logical=($barCount-1)-$i}
                $t=[double]$logical/[Math]::Max(1,$barCount-1)
                $wave=0.25+(0.58*[Math]::Abs([Math]::Sin(($logical+2)*0.73)))
                $bh=[Math]::Max(4,[int][Math]::Min($pmh,$pmh*$wave))

                if(-not $right){$bx=$mediaEdge+($i*$barStep)}
                else{$bx=$mediaEdge-(($i+1)*$barStep)}

                $by=$stripY+$pmh-$bh
                if($anchor -eq 'Top'){$by=$stripY}
                elseif($anchor -eq 'Center' -or $shape -eq 'Center Mirror' -or $shape -eq 'Twin Rails'){$by=$stripY+[int](($pmh-$bh)/2)}
                $colorT=$t
                if([string]$u.visualizer_gradient_orientation -eq 'Vertical'){$colorT=0.60}
                $vc=Preview-VizColor $u $colorT
                $vc=Preview-AlphaColor $vc ([double]$u.visualizer_opacity)
                $vb=New-Object System.Drawing.SolidBrush($vc)
                if([string]$u.visualizer_peak_glow -ne 'Off'){
                    $ga=35;if([string]$u.visualizer_peak_glow -eq 'Strong'){$ga=70}
                    $gb=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb($ga,$vc.R,$vc.G,$vc.B))
                    $g.FillRectangle($gb,$bx-2,$by-2,$barW+4,$bh+4);$gb.Dispose()
                }
                if($shape -eq 'Dots'){
                    for($dy=$by;$dy -lt ($by+$bh);$dy+=5){$g.FillRectangle($vb,$bx,$dy,$barW,[Math]::Min(2,($by+$bh)-$dy))}
                }
                elseif($shape -eq 'Oscilloscope'){
                    $oy=$stripY+[int]($pmh/2)-[int]([Math]::Sin(($logical+2)*0.73)*$bh*0.42)
                    $g.FillEllipse($vb,$bx,$oy,[Math]::Max(2,$barW),[Math]::Max(2,$barW))
                }
                elseif($shape -eq 'Particle Field'){
                    for($p=0;$p -lt 3;$p++){$py=$by+(($logical*7+$p*11)%[Math]::Max(1,$bh));$g.FillRectangle($vb,$bx+(($p*3)%[Math]::Max(1,$barW)),$py,2,2)}
                }
                elseif($shape -eq 'Twin Rails'){
                    $cy=$stripY+[int]($pmh/2);$rail=[Math]::Max(1,[int]($bh/2));$g.FillRectangle($vb,$bx,$cy-$rail,$barW,2);$g.FillRectangle($vb,$bx,$cy+$rail-2,$barW,2)
                }
                else{$g.FillRectangle($vb,$bx,$by,$barW,$bh)}
                $vb.Dispose()
            }
        }

        if([string]$u.visualizer_layer -eq 'Behind text'){& $drawViz}

        # Generic sample text only. Never read playback state or cached metadata.
        $fontSize=[single][Math]::Max(11,[Math]::Min(31,[double]$u.text_size*$scale))
        try{$font=New-Object System.Drawing.Font([string]$u.text_font,$fontSize,[System.Drawing.FontStyle]::Regular)}
        catch{$font=New-Object System.Drawing.Font('Segoe UI',$fontSize,[System.Drawing.FontStyle]::Regular)}

        $align=[string]$u.text_alignment
        if($align -eq 'Auto'){
            if($right){$align='Right'}else{$align='Left'}
        }

        $lineMult=1.08
        if([string]$u.title_channel_spacing -eq 'Tight'){$lineMult=0.96}
        elseif([string]$u.title_channel_spacing -eq 'Loose'){$lineMult=1.22}

        $lineH=[Math]::Max(13,[int][Math]::Round($fontSize*$lineMult))
        $textY=$stripY+4
        $titleRect=New-Object System.Drawing.Rectangle($textX,$textY,$textWidth,[int]($fontSize*1.6))
        $channelRect=New-Object System.Drawing.Rectangle($textX,$textY+$lineH,$textWidth,[int]($fontSize*1.6))

        $textColor=Preview-AlphaColor (Hex-Color ([string]$u.text_color)) ([double]$u.text_opacity)
        $outlineColor=Hex-Color ([string]$u.outline_color)
        $previewOutline=[Math]::Max(0,[Math]::Min(4,[int][Math]::Round([double]$u.text_outline*$scale*0.55)))

        if([bool]$u.title_enabled){
            Preview-DrawText $g 'Artist — Track Title' $font $titleRect $textColor $outlineColor $previewOutline ([bool]$u.text_glow) $align
        }
        if([bool]$u.channel_enabled){
            Preview-DrawText $g 'YouTube Channel' $font $channelRect $textColor $outlineColor $previewOutline ([bool]$u.text_glow) $align
        }

        if([string]$u.visualizer_layer -eq 'Above text'){& $drawViz}
        $font.Dispose()

        # Separate mini-map for canvas/corner placement.
        $mapX=28;$mapY=305;$mapW=210;$mapH=88
        $mapBrush=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(8,8,8))
        $mapPen=New-Object System.Drawing.Pen([System.Drawing.Color]::DimGray,1)
        $g.FillRectangle($mapBrush,$mapX,$mapY,$mapW,$mapH)
        $g.DrawRectangle($mapPen,$mapX,$mapY,$mapW,$mapH)
        $mapBrush.Dispose();$mapPen.Dispose()

        $miniW=[Math]::Max(26,[Math]::Min(96,[int](($m.OverlayWidth/[double]$m.CanvasWidth)*$mapW)))
        $miniH=[Math]::Max(5,[Math]::Min(18,[int](($m.OverlayHeight/[double]$m.CanvasHeight)*$mapH)))
        $miniX=$mapX
        $miniY=$mapY
        if($m.IsRight){$miniX=$mapX+$mapW-$miniW}
        if($m.IsBottom){$miniY=$mapY+$mapH-$miniH}
        $accent=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(125,205,205,205))
        $g.FillRectangle($accent,$miniX,$miniY,$miniW,$miniH)
        $accent.Dispose()

        $infoFont=New-Object System.Drawing.Font('Segoe UI',9)
        $infoBrush=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Silver)
        $g.DrawString(("Canvas placement: "+[string]$u.corner),$infoFont,$infoBrush,260,316)
        $g.DrawString(("Media "+$m.MediaWidth+"x"+$m.MediaHeight+"  |  Browser "+$m.BrowserFps+" FPS"),$infoFont,$infoBrush,260,344)
        $g.DrawString('Generic sample only — playlist and cache are never read.',$infoFont,$infoBrush,260,372)
        $infoBrush.Dispose();$infoFont.Dispose()

        $capBrush.Dispose();$capFont.Dispose()
    }catch{
        # A preview paint problem must never make Settings unusable.
    }
})

$generalPreset.Add_SelectedIndexChanged({Apply-GeneralPreset})
$overlayPreset.Add_SelectedIndexChanged({Apply-OverlayPreset})
$canvasPreset.Add_SelectedIndexChanged({Apply-CanvasPreset;if([string]$mediaPreset.SelectedItem -eq 'Auto'){Apply-MediaPreset};Update-Preview})
$mediaPreset.Add_SelectedIndexChanged({Apply-MediaPreset;Update-Preview})
$stylePreset.Add_SelectedIndexChanged({Apply-StylePreset})
$vizPreset.Add_SelectedIndexChanged({Apply-VisualizerPreset})
$performancePreset.Add_SelectedIndexChanged({Apply-PerformancePreset})
$directorPreset.Add_SelectedIndexChanged({Apply-DirectorPreset})
$outputsPreset.Add_SelectedIndexChanged({Apply-OutputsPreset})
$mode.Add_SelectedIndexChanged({Update-Dependencies;Update-Preview})
foreach($c in @($corner,$font,$textColor,$outlineColor,$textAlign,$textSpacing,$cornerStyle,$vizColorMode,$vizSolid,$vizGradient,$gradientOrientation,$vizDirection,$vizLayer,$vizShape,$vizAnchor,$vizSpacing,$vizPeakGlow,$vizFrequency,$vizFps,$browserFps,$performance,$playerQuality,$videoPreference,$videoFps,$audioQuality,$audioPreference,$activity,$chunk,$vizLength,$directorTheme,$directorTimeline,$directorMotion,$directorPalette,$directorVizShape,$statsDetail,$commentFilter)){ $c.Add_SelectedIndexChanged({Update-Preview}) }
$overlayVideoQuality.Add_SelectedIndexChanged({Update-QualityWarning;Update-Preview})
foreach($n in @($canvasW,$canvasH,$mediaW,$mediaH,$videoZoom,$outlinePx,$textOpacity,$textSize,$borderPx,$opacityPct,$prefetch,$videoCacheLimit,$vizHighTrim,$commentChars,$historyMax)){ $n.Add_ValueChanged({Update-Preview}) }
foreach($c in @($art,$titleCheck,$channel,$viz,$smartCrop,$glow,$borderOn,$loudness)){ $c.Add_CheckedChanged({Update-Preview}) }
$video.Add_CheckedChanged({Update-QualityWarning;Update-Preview})
$directorOn.Add_CheckedChanged({Update-Dependencies;Update-Preview})
$commentOn.Add_CheckedChanged({Update-Dependencies})
$telemetryOn.Add_CheckedChanged({Update-Dependencies})
$historyOn.Add_CheckedChanged({Update-Dependencies})
$vizColorMode.Add_SelectedIndexChanged({Update-Dependencies})
$chunk.Add_SelectedIndexChanged({Update-VisualizerResolutionInfo})
$vizFps.Add_SelectedIndexChanged({Update-VisualizerResolutionInfo})
foreach($row in $outputControls) {
    $row.Enabled.Add_CheckedChanged({Update-Preview})
    $row.Layout.Add_SelectedIndexChanged({Update-Preview})
    $row.Theme.Add_SelectedIndexChanged({Update-Preview})
}

# Page presets are intentionally honest: touching any underlying field turns
# that page into Custom. Programmatic preset application is guarded so it keeps
# the selected preset name while it fills the controls.
foreach($c in @($mode,$playerQuality)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingGeneralPreset -and [string]$generalPreset.SelectedItem -ne 'Custom'){$generalPreset.SelectedItem='Custom'}})
}
foreach($c in @($canvasPreset,$corner,$mediaPreset,$overlayVideoQuality,$videoFps)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingOverlayPreset -and [string]$overlayPreset.SelectedItem -ne 'Custom'){$overlayPreset.SelectedItem='Custom'}})
}
foreach($n in @($canvasW,$canvasH,$mediaW,$mediaH,$videoZoom,$videoCacheLimit)) {
    $n.Add_ValueChanged({if(-not $script:ApplyingOverlayPreset -and [string]$overlayPreset.SelectedItem -ne 'Custom'){$overlayPreset.SelectedItem='Custom'}})
}
foreach($c in @($art,$video,$titleCheck,$channel,$viz,$smartCrop)) {
    $c.Add_CheckedChanged({if(-not $script:ApplyingOverlayPreset -and [string]$overlayPreset.SelectedItem -ne 'Custom'){$overlayPreset.SelectedItem='Custom'}})
}
foreach($c in @($font,$textColor,$outlineColor,$textAlign,$textSpacing,$cornerStyle,$borderColor)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingStylePreset -and [string]$stylePreset.SelectedItem -ne 'Custom'){$stylePreset.SelectedItem='Custom'}})
}
$canvasW.Add_ValueChanged({if(-not $script:ApplyingCanvasPreset -and [string]$canvasPreset.SelectedItem -ne 'Custom'){$canvasPreset.SelectedItem='Custom'}})
$canvasH.Add_ValueChanged({if(-not $script:ApplyingCanvasPreset -and [string]$canvasPreset.SelectedItem -ne 'Custom'){$canvasPreset.SelectedItem='Custom'}})
$mediaW.Add_ValueChanged({if(-not $script:ApplyingMediaPreset -and [string]$mediaPreset.SelectedItem -ne 'Custom'){$mediaPreset.SelectedItem='Custom'}})
$mediaH.Add_ValueChanged({if(-not $script:ApplyingMediaPreset -and [string]$mediaPreset.SelectedItem -ne 'Custom'){$mediaPreset.SelectedItem='Custom'}})
foreach($n in @($outlinePx,$textOpacity,$textSize,$borderPx)) {
    $n.Add_ValueChanged({if(-not $script:ApplyingStylePreset -and [string]$stylePreset.SelectedItem -ne 'Custom'){$stylePreset.SelectedItem='Custom'}})
}
foreach($c in @($glow,$borderOn)) {
    $c.Add_CheckedChanged({if(-not $script:ApplyingStylePreset -and [string]$stylePreset.SelectedItem -ne 'Custom'){$stylePreset.SelectedItem='Custom'}})
}
foreach($c in @($activity,$chunk,$vizLength,$vizColorMode,$vizSolid,$vizGradient,$gradientOrientation,$vizDirection,$vizLayer,$vizShape,$vizAnchor,$vizSpacing,$vizPeakGlow,$vizFrequency,$vizFps)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingVisualizerPreset -and [string]$vizPreset.SelectedItem -ne 'Custom'){$vizPreset.SelectedItem='Custom'}})
}
foreach($n in @($opacityPct,$vizHighTrim)) {
    $n.Add_ValueChanged({if(-not $script:ApplyingVisualizerPreset -and [string]$vizPreset.SelectedItem -ne 'Custom'){$vizPreset.SelectedItem='Custom'}})
}
foreach($c in @($performance,$browserFps,$videoPreference,$audioQuality,$audioPreference)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingPerformancePreset -and [string]$performancePreset.SelectedItem -ne 'Custom'){$performancePreset.SelectedItem='Custom'}})
}
$prefetch.Add_ValueChanged({if(-not $script:ApplyingPerformancePreset -and [string]$performancePreset.SelectedItem -ne 'Custom'){$performancePreset.SelectedItem='Custom'}})
$loudness.Add_CheckedChanged({if(-not $script:ApplyingPerformancePreset -and [string]$performancePreset.SelectedItem -ne 'Custom'){$performancePreset.SelectedItem='Custom'}})
foreach($c in @($directorTheme,$directorTimeline,$directorMotion,$directorPalette,$statsDetail,$directorVizShape,$commentFilter)) {
    $c.Add_SelectedIndexChanged({if(-not $script:ApplyingDirectorPreset -and [string]$directorPreset.SelectedItem -ne 'Custom'){$directorPreset.SelectedItem='Custom'}})
}
foreach($n in @($commentChars,$historyMax)) {
    $n.Add_ValueChanged({if(-not $script:ApplyingDirectorPreset -and [string]$directorPreset.SelectedItem -ne 'Custom'){$directorPreset.SelectedItem='Custom'}})
}
foreach($c in @($directorOn,$commentOn,$telemetryOn,$probeOn,$historyOn)) {
    $c.Add_CheckedChanged({if(-not $script:ApplyingDirectorPreset -and [string]$directorPreset.SelectedItem -ne 'Custom'){$directorPreset.SelectedItem='Custom'}})
}
foreach($row in $outputControls) {
    $row.Enabled.Add_CheckedChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Name.Add_TextChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Modules.Add_TextChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Layout.Add_SelectedIndexChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Theme.Add_SelectedIndexChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Width.Add_ValueChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
    $row.Height.Add_ValueChanged({if(-not $script:ApplyingOutputsPreset -and [string]$outputsPreset.SelectedItem -ne 'Custom'){$outputsPreset.SelectedItem='Custom'}})
}

$refreshComponents.Add_Click({Update-Components})
$checkUpdates.Add_Click({Start-Process (Join-Path $PSScriptRoot 'YomiLauncher.exe') -ArgumentList 'update'})
$denoBtn.Add_Click({
    $a = 'InstallDeno'
    if (Test-YomiComponent 'deno') { $a = 'RemoveDeno' }
    Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'components.ps1'),'-Action',$a)
})
$ffmpegBtn.Add_Click({
    $a = 'InstallFfmpeg'
    if (Test-YomiComponent 'ffmpeg') { $a = 'RemoveFfmpeg' }
    Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'components.ps1'),'-Action',$a)
})
$openData.Add_Click({Start-Process explorer.exe $DataRoot})
$openProgram.Add_Click({Start-Process explorer.exe $InstallRoot})
$uninstallBtn.Add_Click({
    $answer=[System.Windows.Forms.MessageBox]::Show(
        "Open the YOMI uninstaller?`r`n`r`nThe uninstaller will ask whether to remove everything or keep your playlist/config for a future reinstall.",
        'Uninstall YOMI',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}

    $rootUninstaller=Join-Path $InstallRoot 'Uninstall YOMI.cmd'
    $scriptUninstaller=Join-Path $InstallRoot 'app\uninstall.ps1'

    if(Test-Path $rootUninstaller){
        Start-Process $rootUninstaller
        $form.Close()
        return
    }

    # Defensive fallback to the real uninstall engine.
    if(Test-Path $scriptUninstaller){
        $escaped=$scriptUninstaller.Replace("'","''")
        Start-Process powershell.exe -ArgumentList @(
            '-NoProfile',
            '-ExecutionPolicy','Bypass',
            '-Command',
            ("& '"+$escaped+"'")
        )
        $form.Close()
        return
    }

    [System.Windows.Forms.MessageBox]::Show(
        "The YOMI uninstall engine could not be found.`r`n`r`nExpected:`r`n$scriptUninstaller",
        'YOMI',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )|Out-Null
})
$controllerBtn.Add_Click({Start-Process (Join-Path $PSScriptRoot 'YomiLauncher.exe') -ArgumentList 'controller'})
$readme.Add_Click({Start-Process notepad.exe ('"'+(Join-Path $InstallRoot 'README-EASY.txt')+'"')})
$copyOverlay.Add_Click({[System.Windows.Forms.Clipboard]::SetText((Get-OverlayUrl (Get-UiConfig)));[System.Windows.Forms.MessageBox]::Show('Overlay URL copied.','YOMI')|Out-Null})
$obsSetup.Add_Click({$p=Write-ObsInstructions (Get-UiConfig);Start-Process notepad.exe ('"'+$p+'"')})
$copySources.Add_Click({
    $p=Write-ObsInstructions (Get-UiConfig)
    [System.Windows.Forms.Clipboard]::SetText((Get-Content $p -Raw))
    [System.Windows.Forms.MessageBox]::Show('All classic and Director Source URLs copied.','YOMI Director Mode')|Out-Null
})
$openObsGuide.Add_Click({$p=Write-ObsInstructions (Get-UiConfig);Start-Process notepad.exe ('"'+$p+'"')})
$restoreDefaults.Add_Click({
    $answer=[System.Windows.Forms.MessageBox]::Show(
        "Restore factory settings?`r`n`r`nThis resets YOMI options and output layouts. Your playlist, playback history, installed components and Defender choice stay intact. Media affected by quality, crop or visualizer defaults will rebuild on the next start.",
        'Restore Default Settings',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}

    $defaults=Get-Content (Join-Path $PSScriptRoot 'default-config.json') -Raw | ConvertFrom-Json
    $defaults.playlist=$playlist.Text.Trim()
    $defaults.version=$yomiVersion
    Save-YomiConfig $defaults
    $stateRoot=Join-Path $DataRoot 'state';New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
    foreach($flag in @('audio-reset.pending','artwork-reset.pending','video-reset.pending','visualizer-reset.pending')){Set-Content (Join-Path $stateRoot $flag) '1' -Encoding ASCII}
    Write-ObsInstructions $defaults | Out-Null
    Start-Process (Join-Path $PSScriptRoot 'YomiLauncher.exe') -ArgumentList 'settings'
    $form.Close()
})
$shuffleBtn.Add_Click({
    $answer=[System.Windows.Forms.MessageBox]::Show(
        "Shuffle Playlist now?`r`n`r`nYOMI will reload the latest contents from YouTube, preserve every playlist occurrence, randomize the list, reset track-number cache and restart from track 1.",
        'Shuffle Playlist',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )

    if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}

    # Save the current Settings UI first so a newly edited playlist URL is
    # exactly what Shuffle Playlist reloads.
    $new=Get-UiConfig
    $new.version=$yomiVersion
    $new.playlist=$playlist.Text.Trim()
    $metrics=Get-YomiLayoutMetrics $new
    $new.overlay_width=[int]$metrics.OverlayWidth
    $new.overlay_height=[int]$metrics.OverlayHeight
    $new.overlay_fps=[int]$metrics.BrowserFps
    Save-YomiConfig $new

    $stateRoot=Join-Path $DataRoot 'state'
    New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
    Set-Content (Join-Path $stateRoot 'shuffle-request.txt') 'approved' -Encoding ASCII

    # If Controller is already running its timer sees the request. If it is not,
    # launching it makes the same request get consumed immediately.
    Start-Process (Join-Path $PSScriptRoot 'YomiLauncher.exe') -ArgumentList 'controller'
})

$save.Add_Click({
    $old=Get-YomiConfig; $new=Get-UiConfig; $new.version=$yomiVersion; $new.playlist=$playlist.Text.Trim()
    $metrics=Get-YomiLayoutMetrics $new; $new.overlay_width=[int]$metrics.OverlayWidth; $new.overlay_height=[int]$metrics.OverlayHeight; $new.overlay_fps=[int]$metrics.BrowserFps
    $playlistChanged=([string]$old.playlist -ne [string]$new.playlist)
    $vizSigBefore="$($old.visualizer_internal_width)x$($old.visualizer_internal_height)|$($old.visualizer_activity)|$($old.visualizer_frequency_scale)|$($old.visualizer_fps)"; $vizSigAfter="$($new.visualizer_internal_width)x$($new.visualizer_internal_height)|$($new.visualizer_activity)|$($new.visualizer_frequency_scale)|$($new.visualizer_fps)"
    $artSigBefore="$($old.media_width)x$($old.media_height)|$($old.smart_artwork_crop)"; $artSigAfter="$($new.media_width)x$($new.media_height)|$($new.smart_artwork_crop)"
    $videoSigBefore="$($old.overlay_video_quality)|$($old.video_preference)|$($old.video_fps)"; $videoSigAfter="$($new.overlay_video_quality)|$($new.video_preference)|$($new.video_fps)"
    $audioSigBefore="$($old.audio_quality)|$($old.audio_preference)"; $audioSigAfter="$($new.audio_quality)|$($new.audio_preference)"
    $commentSigBefore="$($old.featured_comment_enabled)|$($old.comment_max_chars)|$($old.comment_filter_mode)"; $commentSigAfter="$($new.featured_comment_enabled)|$($new.comment_max_chars)|$($new.comment_filter_mode)"
    Save-YomiConfig $new
    if($playlistChanged){Remove-Item (Join-Path $DataRoot 'playlist.txt') -Force -ErrorAction SilentlyContinue;Set-Content (Join-Path $DataRoot 'state\resume-track.txt') '1' -Encoding ASCII}
    if($vizSigBefore -ne $vizSigAfter){Set-Content (Join-Path $DataRoot 'state\visualizer-reset.pending') '1' -Encoding ASCII}
    if($artSigBefore -ne $artSigAfter){Set-Content (Join-Path $DataRoot 'state\artwork-reset.pending') '1' -Encoding ASCII}
    if($videoSigBefore -ne $videoSigAfter){Set-Content (Join-Path $DataRoot 'state\video-reset.pending') '1' -Encoding ASCII}
    if($audioSigBefore -ne $audioSigAfter){Set-Content (Join-Path $DataRoot 'state\audio-reset.pending') '1' -Encoding ASCII}
    if($commentSigBefore -ne $commentSigAfter){Get-ChildItem (Join-Path $DataRoot 'cache\comments') -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue;Get-ChildItem (Join-Path $DataRoot 'cache\status') -Filter 'track-*.comment.*' -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue}
    Write-ObsInstructions $new | Out-Null
    $saveResetTimer.Stop();$save.Text='SAVED';$saveResetTimer.Start()
    $config=$new;Update-Dependencies;Update-Preview
})

Update-Components
Update-Dependencies
Update-VisualizerResolutionInfo
Update-Preview
Write-ObsInstructions $config | Out-Null
$form.Add_Shown({Start-Process (Join-Path $PSScriptRoot 'YomiLauncher.exe') -ArgumentList 'update-auto'})
try{[void]$form.ShowDialog()}finally{$saveResetTimer.Stop();$saveResetTimer.Dispose()}
